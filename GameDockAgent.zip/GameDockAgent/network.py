"""
GameDock Agent - utilità di rete: IP locale, MAC address, tipo di connessione,
pacchetto magico Wake-on-LAN, controllo indirizzi LAN.
"""

import ipaddress
import re
import socket
import subprocess
import sys
import uuid

IS_WINDOWS = sys.platform.startswith("win")
MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$")
_MAC_IN_TEXT = re.compile(r"([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}")


def local_ip():
    """IP della scheda usata per uscire sulla rete (nessun pacchetto viene davvero inviato)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def adapter_info():
    """Ritorna {"ip", "mac", "connection": "wifi"|"ethernet"|"unknown"} della scheda attiva."""
    ip = local_ip()
    info = {"ip": ip, "mac": None, "connection": "unknown"}
    if IS_WINDOWS:
        try:
            out = subprocess.run(["ipconfig", "/all"], capture_output=True, text=True,
                                 errors="ignore", creationflags=subprocess.CREATE_NO_WINDOW).stdout
            header, mac = "", None
            for line in out.splitlines():
                if line and not line.startswith(" ") and line.rstrip().endswith(":"):
                    header, mac = line.lower(), None      # inizio di una nuova scheda
                    continue
                found = _MAC_IN_TEXT.search(line)
                if found and mac is None:
                    mac = found.group(0)
                if re.search(r"(?<![\d.])" + re.escape(ip) + r"(?![\d.])", line):
                    info["mac"] = mac.replace("-", ":").upper() if mac else None
                    wireless = any(w in header for w in ("wireless", "wi-fi", "wlan"))
                    info["connection"] = "wifi" if wireless else "ethernet"
                    break
        except OSError:
            pass
    if not info["mac"]:
        node = uuid.getnode()
        info["mac"] = ":".join(f"{(node >> s) & 0xff:02X}" for s in range(40, -1, -8))
    return info


def is_lan_address(addr):
    try:
        ip = ipaddress.ip_address(addr.split("%")[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_private or ip.is_loopback or ip.is_link_local


def is_loopback(addr):
    try:
        ip = ipaddress.ip_address(addr.split("%")[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_loopback


def normalize_mac(mac):
    if not mac or not MAC_RE.match(mac.strip()):
        raise ValueError("MAC address non valido. Formato atteso: AA:BB:CC:DD:EE:FF")
    return mac.strip().replace("-", ":").upper()


def send_magic_packet(mac, broadcast="255.255.255.255", port=9):
    """Invia il pacchetto magico Wake-on-LAN (6 x 0xFF + 16 ripetizioni del MAC)."""
    mac = normalize_mac(mac)
    payload = bytes.fromhex("FF" * 6 + mac.replace(":", "") * 16)
    targets = {broadcast or "255.255.255.255", "255.255.255.255"}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for target in targets:
            for p in {int(port or 9), 7}:
                s.sendto(payload, (target, p))
    return mac


def tcp_reachable(host, port, timeout=1.5):
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except OSError:
        return False
