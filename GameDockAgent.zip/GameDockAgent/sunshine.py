"""
GameDock Agent - integrazione con Sunshine (server di streaming sul PC).

Usa l'API web di Sunshine (la stessa del suo pannello su https://localhost:47990):
- test():  verifica indirizzo e credenziali
- sync():  registra ogni gioco di GameDock come "app" di Sunshine, così in Moonlight
           compaiono i singoli giochi (non solo "Desktop") e lo streaming parte
           direttamente nel gioco
- pin():   abbina un dispositivo Moonlight inserendo il PIN da GameDock (anche dalla TV)

Le credenziali sono quelle create al primo avvio di Sunshine e restano solo sul PC
(config.json). Sunshine usa un certificato auto-firmato: la verifica TLS è disattivata
SOLO per indirizzi locali.
"""

import base64
import json
import logging
import os
import ssl
import urllib.error
import urllib.parse
import urllib.request

import network
import storage

log = logging.getLogger("gamedock.sunshine")


class SunshineError(Exception):
    pass


def _context(url):
    host = urllib.parse.urlparse(url).hostname or ""
    if host not in ("localhost", "127.0.0.1", "::1") and not network.is_lan_address(host):
        raise SunshineError("Per sicurezza Sunshine deve essere sul PC o sulla rete di casa.")
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE       # certificato auto-firmato di Sunshine
    return ctx


def _request(cfg, method, path, body=None, timeout=10):
    base = (cfg.get("url") or "https://localhost:47990").rstrip("/")
    if not cfg.get("username") or not cfg.get("password"):
        raise SunshineError("Inserisci nome utente e password di Sunshine nelle impostazioni.")
    token = base64.b64encode(f"{cfg['username']}:{cfg['password']}".encode()).decode()
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, method=method, headers={
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_context(base)) as res:  # noqa: S310
            raw = res.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise SunshineError("Nome utente o password di Sunshine errati.")
        raise SunshineError(f"Sunshine ha risposto con errore {e.code}.")
    except (urllib.error.URLError, OSError) as e:
        raise SunshineError(f"Sunshine non raggiungibile ({getattr(e, 'reason', e)}). È avviato?")
    try:
        return json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        return {}


def list_apps(cfg):
    data = _request(cfg, "GET", "/api/apps")
    return data.get("apps", []) if isinstance(data, dict) else []


def test(cfg):
    apps = list_apps(cfg)
    return {"ok": True, "apps": len(apps)}


def resolution_prep():
    """Comandi che Sunshine esegue prima/dopo lo streaming: risoluzione del PC = risoluzione del dispositivo."""
    import shortcuts  # evita import circolari
    target, args = shortcuts.launcher_command()
    base = f'"{target}" ' + args.replace("--open-console", "").strip()
    return [{
        "do": f"{base} --set-resolution %SUNSHINE_CLIENT_WIDTH%x%SUNSHINE_CLIENT_HEIGHT%@%SUNSHINE_CLIENT_FPS%",
        "undo": f"{base} --restore-resolution",
        "elevated": False,
    }]


def _app_for(game, auto_resolution=False):
    """Traduce un gioco di GameDock in un'app di Sunshine."""
    launch = game.get("launch") or {}
    app = {
        "name": game["name"],
        "output": "",
        "cmd": "",
        "detached": [],
        "working-dir": "",
        "prep-cmd": [],
        "exclude-global-prep-cmd": False,
        "elevated": False,
        "auto-detach": True,      # i launcher terminano subito: lo streaming resta attivo
        "wait-all": True,         # lo streaming finisce quando si chiude il gioco
        "exit-timeout": 5,
        "index": -1,
    }
    kind = launch.get("type")
    if kind == "steam":
        app["detached"] = [f"steam://rungameid/{launch.get('appid')}"]
    elif kind == "uri":
        app["detached"] = [launch["uri"]]
    elif kind == "battlenet":
        app["detached"] = [f'"{launch.get("exe")}" --exec="launch {launch.get("code")}"']
    elif kind == "shell":
        app["detached"] = [f'explorer.exe shell:AppsFolder\\{launch.get("family")}!{launch.get("app")}']
    else:
        exe = launch.get("path") or game.get("executable")
        if not exe:
            return None
        args = launch.get("args", "")
        app["cmd"] = f'"{exe}" {args}'.strip()
        app["working-dir"] = os.path.dirname(exe)
    if auto_resolution:
        app["prep-cmd"] = resolution_prep()
    cover = game.get("coverFile")
    if cover and cover.lower().endswith(".png") and os.path.isfile(cover):
        app["image-path"] = cover     # Sunshine accetta solo PNG come copertina
    return app


def sync(cfg, games):
    """Crea/aggiorna le app di Sunshine per i giochi visibili e rimuove quelle non più presenti.
    Tocca solo le app create da GameDock: quelle aggiunte a mano in Sunshine restano com'erano.
    games: lista di giochi "raw" (con launch) già filtrati (niente nascosti)."""
    lib = storage.load_library()
    managed = set(lib.get("sunshineApps", []))
    existing = list_apps(cfg)
    by_name = {a.get("name"): i for i, a in enumerate(existing)}
    owned, created, updated, skipped = [], 0, 0, 0

    for game in games:
        app = _app_for(game, cfg.get("autoResolution", True))
        if not app or app["name"] in owned:
            continue
        index = by_name.get(app["name"])
        if index is not None and app["name"] not in managed:
            skipped += 1           # app con lo stesso nome creata a mano: non la tocchiamo
            continue
        if index is not None:
            app["index"] = index
            updated += 1
        else:
            created += 1
        _request(cfg, "POST", "/api/apps", app)
        owned.append(app["name"])

    # Rimuove le app create da GameDock per giochi eliminati o nascosti (dall'indice più alto)
    removed = 0
    stale = managed - set(owned)
    if stale:
        current = list_apps(cfg)
        for index in sorted((i for i, a in enumerate(current) if a.get("name") in stale), reverse=True):
            _request(cfg, "DELETE", f"/api/apps/{index}")
            removed += 1

    def mutate(lib):
        lib["sunshineApps"] = sorted(owned)
    storage.update_library(mutate)
    log.info("Sunshine: %s create, %s aggiornate, %s rimosse, %s lasciate com'erano",
             created, updated, removed, skipped)
    return {"created": created, "updated": updated, "removed": removed, "skipped": skipped, "total": len(owned)}


def pin(cfg, code, device_name):
    code = "".join(ch for ch in str(code) if ch.isdigit())
    if len(code) != 4:
        raise SunshineError("Il PIN di Moonlight ha 4 cifre.")
    result = _request(cfg, "POST", "/api/pin", {"pin": code, "name": (device_name or "GameDock")[:40]})
    if isinstance(result, dict) and str(result.get("status", "true")).lower() in ("false", "0"):
        raise SunshineError("PIN non accettato: controlla le cifre e riprova subito, scade in pochi minuti.")
    return {"ok": True}
