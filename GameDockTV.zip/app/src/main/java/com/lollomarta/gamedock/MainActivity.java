package com.lollomarta.gamedock;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * GameDock TV.
 *
 * Carica GameDock dal PC (http://IP-DEL-PC:8765) in una WebView a schermo intero e aggiunge
 * ciò che un browser non può fare:
 *  - trova da sola il PC sulla rete al primo avvio
 *  - se il PC è spento mostra una schermata nativa con "Accendi PC" (Wake-on-LAN)
 *  - apre Moonlight in modo affidabile
 * La pagina web comunica con l'app tramite l'oggetto JavaScript "GameDockAndroid".
 */
public class MainActivity extends Activity {

    private static final int AGENT_PORT = 8765;
    private static final String MOONLIGHT_PACKAGE = "com.limelight";
    private static final String PREFS = "gamedock";
    private static final int GREEN = Color.parseColor("#22C55E");
    private static final int BG = Color.parseColor("#08090D");
    private static final int SURFACE = Color.parseColor("#191C25");
    private static final int TEXT_2 = Color.parseColor("#9CA3AF");

    private enum Screen { NONE, STATUS, SETUP, OFFLINE }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private SharedPreferences prefs;
    private WebView web;
    private LinearLayout overlay;
    private TextView titleView;
    private TextView messageView;
    private EditText addressInput;
    private LinearLayout buttonRow;
    private Screen screen = Screen.NONE;
    private volatile int attempt = 0;      // invalida le operazioni in corso quando si cambia schermata
    private boolean pendingInstall = false; // in attesa del permesso "installa app sconosciute"

    // ------------------------------------------------------------------ ciclo di vita

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildLayout();
        goImmersive();
        start();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (pendingInstall && canInstall()) {
            pendingInstall = false;
            launchInstaller();
        }
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        web.destroy();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // ------------------------------------------------------------------ interfaccia

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void buildLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString(s.getUserAgentString() + " GameDockTV/1.0");
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);   // debug da Chrome sul PC
        }
        web.addJavascriptInterface(new Bridge(), "GameDockAndroid");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new GameDockClient());
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Schermata nativa (primo avvio, ricerca PC, PC spento)
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER);
        overlay.setBackgroundColor(BG);
        overlay.setPadding(dp(48), dp(32), dp(48), dp(32));
        overlay.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(88), dp(88));
        logoLp.bottomMargin = dp(20);
        overlay.addView(logo, logoLp);

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(30);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setGravity(Gravity.CENTER);
        overlay.addView(titleView, wrap());

        messageView = new TextView(this);
        messageView.setTextColor(TEXT_2);
        messageView.setTextSize(17);
        messageView.setGravity(Gravity.CENTER);
        messageView.setLineSpacing(0, 1.2f);
        LinearLayout.LayoutParams msgLp = wrap();
        msgLp.topMargin = dp(12);
        msgLp.bottomMargin = dp(24);
        overlay.addView(messageView, msgLp);

        addressInput = new EditText(this);
        addressInput.setHint("192.168.1.20");
        addressInput.setHintTextColor(Color.parseColor("#5B6170"));
        addressInput.setTextColor(Color.WHITE);
        addressInput.setTextSize(20);
        addressInput.setSingleLine(true);
        addressInput.setGravity(Gravity.CENTER);
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressInput.setBackground(rounded(SURFACE, Color.parseColor("#2A2F3D"), dp(12)));
        addressInput.setPadding(dp(20), dp(14), dp(20), dp(14));
        addressInput.setOnEditorActionListener((v, actionId, event) -> {
            connectToTyped();
            return true;
        });
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT);
        inLp.bottomMargin = dp(20);
        overlay.addView(addressInput, inLp);

        buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.CENTER);
        overlay.addView(buttonRow, wrap());

        TextView credit = new TextView(this);
        credit.setText("GameDock · created by LolloMarta");
        credit.setTextColor(Color.parseColor("#4B5160"));
        credit.setTextSize(13);
        LinearLayout.LayoutParams creditLp = wrap();
        creditLp.topMargin = dp(36);
        overlay.addView(credit, creditLp);

        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void showScreen(Screen which, String title, String message, boolean withInput) {
        attempt++;
        screen = which;
        overlay.setVisibility(View.VISIBLE);
        titleView.setText(title);
        messageView.setText(message);
        addressInput.setVisibility(withInput ? View.VISIBLE : View.GONE);
        buttonRow.removeAllViews();
    }

    private void hideOverlay() {
        screen = Screen.NONE;
        overlay.setVisibility(View.GONE);
        web.requestFocus();
    }

    private Button addButton(String label, boolean primary, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(26), dp(12), dp(26), dp(12));
        b.setFocusable(true);
        // Selezione ben visibile col telecomando: bordo e sfondo verdi quando ha il focus
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(GREEN, Color.WHITE, dp(12)));
        bg.addState(new int[]{android.R.attr.state_pressed}, rounded(GREEN, GREEN, dp(12)));
        bg.addState(new int[]{}, rounded(primary ? Color.parseColor("#15803D") : SURFACE,
                Color.parseColor("#2A2F3D"), dp(12)));
        b.setBackground(bg);
        b.setOnClickListener(action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(8), 0, dp(8), 0);
        buttonRow.addView(b, lp);
        return b;
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        d.setStroke(dp(2), stroke);
        return d;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------ flusso principale

    private String server() {
        return prefs.getString("server", "");
    }

    private void start() {
        if (server().isEmpty()) {
            discover();
        } else {
            checkAndLoad();
        }
    }

    /** Controlla che l'Agent risponda, poi carica GameDock. */
    private void checkAndLoad() {
        final String base = server();
        showScreen(Screen.STATUS, "GameDock", "Connessione al PC…", false);
        final int myAttempt = attempt;
        executor.execute(() -> {
            final boolean ok = isAgentAt(base);
            main.post(() -> {
                if (myAttempt != attempt) return;
                if (ok) {
                    web.loadUrl(base + "/");
                } else {
                    showOffline();
                }
            });
        });
    }

    private void showOffline() {
        String mac = prefs.getString("mac", "");
        showScreen(Screen.OFFLINE, "PC spento o non raggiungibile",
                "GameDock non risponde su " + server() + ".\n"
                        + (mac.isEmpty()
                        ? "Accendi il PC e avvia GameDock Agent, poi premi Riprova."
                        : "Premi Accendi PC per accenderlo con Wake-on-LAN (serve il PC collegato via cavo)."),
                false);
        Button first;
        if (!mac.isEmpty()) {
            first = addButton("Accendi PC", true, v -> wakeAndWait());
            addButton("Riprova", false, v -> checkAndLoad());
        } else {
            first = addButton("Riprova", true, v -> checkAndLoad());
        }
        addButton("Apri Moonlight", false, v -> openMoonlight());
        addButton("Cambia PC", false, v -> showSetup(""));
        first.requestFocus();
    }

    private void showSetup(String note) {
        showScreen(Screen.SETUP, "Collega GameDock al PC",
                (note.isEmpty() ? "" : note + "\n")
                        + "Scrivi l'indirizzo IP del PC (lo trovi nella finestra di GameDock Agent, riga \"Apri\").",
                true);
        String current = server().replace("http://", "").replace(":" + AGENT_PORT, "");
        addressInput.setText(current);
        Button connect = addButton("Connetti", true, v -> connectToTyped());
        addButton("Cerca il PC", false, v -> discover());
        if (current.isEmpty()) addressInput.requestFocus();
        else connect.requestFocus();
    }

    private void connectToTyped() {
        String typed = addressInput.getText().toString().trim();
        if (typed.isEmpty()) return;
        String url = typed.startsWith("http") ? typed : "http://" + typed;
        if (!url.substring(url.indexOf("//") + 2).contains(":")) url += ":" + AGENT_PORT;
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        prefs.edit().putString("server", url).apply();
        checkAndLoad();
    }

    // ------------------------------------------------------------------ ricerca del PC

    /** Cerca GameDock Agent sulla rete locale (porta 8765) provando tutti gli indirizzi della sottorete. */
    private void discover() {
        showScreen(Screen.STATUS, "Ricerca del PC…", "Sto cercando GameDock Agent sulla rete di casa.", false);
        final int myAttempt = attempt;
        executor.execute(() -> {
            String found = null;
            for (String prefix : localPrefixes()) {
                found = scanSubnet(prefix, myAttempt);
                if (found != null || myAttempt != attempt) break;
            }
            final String result = found;
            main.post(() -> {
                if (myAttempt != attempt) return;
                if (result != null) {
                    prefs.edit().putString("server", result).apply();
                    checkAndLoad();
                } else {
                    showSetup("Non ho trovato il PC automaticamente. Controlla che GameDock Agent sia avviato "
                            + "e che TV e PC siano sulla stessa rete.");
                }
            });
        });
    }

    private List<String> localPrefixes() {
        Set<String> prefixes = new LinkedHashSet<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (addr instanceof Inet4Address && addr.isSiteLocalAddress()) {
                        String ip = addr.getHostAddress();
                        prefixes.add(ip.substring(0, ip.lastIndexOf('.') + 1));
                    }
                }
            }
        } catch (Exception ignored) {
            // nessuna rete: la lista resta vuota
        }
        return new ArrayList<>(prefixes);
    }

    private String scanSubnet(final String prefix, final int myAttempt) {
        ExecutorService pool = Executors.newFixedThreadPool(48);
        final AtomicBoolean done = new AtomicBoolean(false);
        final String[] result = {null};
        final AtomicInteger checked = new AtomicInteger(0);
        for (int i = 1; i <= 254; i++) {
            final String ip = prefix + i;
            pool.execute(() -> {
                if (done.get() || myAttempt != attempt) return;
                if (portOpen(ip, AGENT_PORT, 350) && isAgentAt("http://" + ip + ":" + AGENT_PORT)) {
                    if (done.compareAndSet(false, true)) result[0] = "http://" + ip + ":" + AGENT_PORT;
                }
                final int n = checked.incrementAndGet();
                if (n % 16 == 0) {
                    main.post(() -> {
                        if (myAttempt == attempt && screen == Screen.STATUS) {
                            messageView.setText("Sto cercando GameDock Agent sulla rete di casa… "
                                    + Math.min(100, n * 100 / 254) + "%");
                        }
                    });
                }
            });
        }
        pool.shutdown();
        try {
            pool.awaitTermination(30, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        return result[0];
    }

    private static boolean portOpen(String ip, int port, int timeoutMs) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ip, port), timeoutMs);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isAgentAt(String base) {
        if (base == null || base.isEmpty()) return false;
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(base + "/api/health").openConnection();
            conn.setConnectTimeout(2500);
            conn.setReadTimeout(2500);
            if (conn.getResponseCode() != 200) return false;
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            reader.close();
            return body.toString().contains("ok");
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ------------------------------------------------------------------ Wake-on-LAN

    private void wakeAndWait() {
        final String mac = prefs.getString("mac", "");
        final String broadcast = prefs.getString("broadcast", "255.255.255.255");
        showScreen(Screen.STATUS, "Accensione PC…", "Invio del segnale di accensione…", false);
        addButton("Annulla", false, v -> showOffline()).requestFocus();
        final int myAttempt = attempt;
        final String base = server();
        executor.execute(() -> {
            sendMagicPacket(mac, broadcast);
            long start = System.currentTimeMillis();
            while (myAttempt == attempt && System.currentTimeMillis() - start < 150_000) {
                if (isAgentAt(base)) {
                    main.post(() -> {
                        if (myAttempt == attempt) web.loadUrl(base + "/");
                    });
                    return;
                }
                final long seconds = (System.currentTimeMillis() - start) / 1000;
                main.post(() -> {
                    if (myAttempt == attempt) {
                        messageView.setText("In attesa che il PC si accenda e avvii GameDock Agent… " + seconds + " s");
                    }
                });
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    return;
                }
            }
            main.post(() -> {
                if (myAttempt == attempt) {
                    showOffline();
                    messageView.setText("Il PC non si è acceso. Controlla che sia collegato via cavo e che "
                            + "Wake-on-LAN sia attivo nel BIOS, oppure usa \"Wake PC\" in Moonlight.");
                }
            });
        });
    }

    /** Pacchetto magico: 6 x 0xFF + 16 ripetizioni del MAC, inviato in broadcast sulle porte 9 e 7. */
    private boolean sendMagicPacket(String mac, String broadcast) {
        String hex = mac.replaceAll("[^0-9A-Fa-f]", "");
        if (hex.length() != 12) return false;
        byte[] macBytes = new byte[6];
        for (int i = 0; i < 6; i++) {
            macBytes[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        byte[] packet = new byte[6 + 16 * 6];
        for (int i = 0; i < 6; i++) packet[i] = (byte) 0xFF;
        for (int i = 6; i < packet.length; i += 6) System.arraycopy(macBytes, 0, packet, i, 6);

        Set<String> targets = new LinkedHashSet<>();
        targets.add("255.255.255.255");
        if (broadcast != null && !broadcast.isEmpty()) targets.add(broadcast);
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getBroadcast() != null) targets.add(ia.getBroadcast().getHostAddress());
                }
            }
        } catch (Exception ignored) {
            // si usano solo gli indirizzi già noti
        }
        boolean sent = false;
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            for (String target : targets) {
                for (int port : new int[]{9, 7}) {
                    try {
                        InetAddress address = InetAddress.getByName(target);
                        socket.send(new DatagramPacket(packet, packet.length, address, port));
                        sent = true;
                    } catch (Exception ignored) {
                        // prova il prossimo indirizzo
                    }
                }
            }
        } catch (Exception ignored) {
            return false;
        }
        return sent;
    }

    // ------------------------------------------------------------------ Moonlight

    private boolean openMoonlight() {
        PackageManager pm = getPackageManager();
        Intent intent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            intent = pm.getLeanbackLaunchIntentForPackage(MOONLIGHT_PACKAGE);
        }
        if (intent == null) intent = pm.getLaunchIntentForPackage(MOONLIGHT_PACKAGE);
        try {
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            }
            // Moonlight non installato: apre la sua pagina nel Play Store
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + MOONLIGHT_PACKAGE)));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + MOONLIGHT_PACKAGE)));
            } catch (ActivityNotFoundException ignored) {
                // nessun negozio disponibile
            }
        }
        return false;
    }

    /**
     * Apre Moonlight direttamente nello streaming, senza passare dai suoi menu.
     * Usa ShortcutTrampoline di Moonlight (lo stesso dei collegamenti sulla schermata della TV):
     * PC indicato con UUID e/o nome, app di Sunshine indicata per nome (es. "Desktop").
     * Se non funziona (Moonlight vecchio o assente) apre Moonlight normalmente.
     */
    private void startStream(String uuid, String pcName, String appName) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setComponent(new ComponentName(MOONLIGHT_PACKAGE, MOONLIGHT_PACKAGE + ".ShortcutTrampoline"));
        if (uuid != null && !uuid.isEmpty()) intent.putExtra("UUID", uuid);
        if (pcName != null && !pcName.isEmpty()) intent.putExtra("Name", pcName);
        intent.putExtra("AppName", appName == null || appName.isEmpty() ? "Desktop" : appName);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (Exception e) {
            openMoonlight();
        }
    }

    private boolean isTv() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
    }

    // ------------------------------------------------------------------ aggiornamenti

    @SuppressWarnings("deprecation")
    private int versionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? (int) info.getLongVersionCode() : info.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return 0;
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    /** Scarica l'APK più recente dal PC (cartella apk dell'Agent) e avvia l'installazione. */
    private void downloadUpdate() {
        final String url = server() + "/api/app/android/download";
        showScreen(Screen.STATUS, "Aggiornamento di GameDock TV", "Scaricamento dal PC… 0%", false);
        addButton("Annulla", false, v -> hideOverlay()).requestFocus();
        final int myAttempt = attempt;
        executor.execute(() -> {
            final File target = ApkProvider.apkFile(this);
            HttpURLConnection conn = null;
            boolean ok = false;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(20000);
                if (conn.getResponseCode() == 200) {
                    long total = conn.getContentLength();
                    long done = 0;
                    int lastPercent = -1;
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(target)) {
                        byte[] buffer = new byte[64 * 1024];
                        int n;
                        while ((n = in.read(buffer)) > 0) {
                            if (myAttempt != attempt) return;           // annullato
                            out.write(buffer, 0, n);
                            done += n;
                            final int percent = total > 0 ? (int) (done * 100 / total) : 0;
                            if (percent != lastPercent) {
                                lastPercent = percent;
                                main.post(() -> {
                                    if (myAttempt == attempt) messageView.setText("Scaricamento dal PC… " + percent + "%");
                                });
                            }
                        }
                    }
                    ok = total <= 0 || done == total;
                }
            } catch (Exception ignored) {
                ok = false;
            } finally {
                if (conn != null) conn.disconnect();
            }
            final boolean success = ok;
            main.post(() -> {
                if (myAttempt != attempt) return;
                if (success) {
                    installUpdate();
                } else {
                    showScreen(Screen.STATUS, "Aggiornamento non riuscito",
                            "Non sono riuscito a scaricare l'aggiornamento dal PC. Riprova tra poco.", false);
                    addButton("Riprova", true, v -> downloadUpdate()).requestFocus();
                    addButton("Chiudi", false, v -> hideOverlay());
                }
            });
        });
    }

    private boolean canInstall() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getPackageManager().canRequestPackageInstalls();
    }

    private void installUpdate() {
        if (canInstall()) {
            launchInstaller();
            return;
        }
        // Android 8+: la prima volta bisogna consentire a GameDock di installare app
        showScreen(Screen.STATUS, "Consenti l'aggiornamento",
                "Per aggiornarsi, GameDock deve poter installare app.\n"
                        + "Premi \"Apri impostazioni\", attiva \"Consenti da questa origine\" e torna indietro:\n"
                        + "l'installazione partirà da sola.", false);
        addButton("Apri impostazioni", true, v -> {
            pendingInstall = true;
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
            }
        }).requestFocus();
        addButton("Annulla", false, v -> {
            pendingInstall = false;
            hideOverlay();
        });
    }

    private void launchInstaller() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(ApkProvider.URI, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
            hideOverlay();
        } catch (ActivityNotFoundException e) {
            showScreen(Screen.STATUS, "Aggiornamento non riuscito",
                    "Questo dispositivo non permette di installare l'aggiornamento da qui. "
                            + "Installalo a mano con Send Files to TV.", false);
            addButton("Chiudi", true, v -> hideOverlay()).requestFocus();
        }
    }

    // ------------------------------------------------------------------ WebView

    private class GameDockClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            if (url != null && url.startsWith("http") && screen == Screen.STATUS) hideOverlay();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && request.isForMainFrame()) {
                main.post(MainActivity.this::showOffline);
            }
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) main.post(MainActivity.this::showOffline);
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUrl(request.getUrl().toString());
        }

        private boolean handleUrl(String url) {
            if (url.startsWith("http://") || url.startsWith("https://")) return false;
            // Link di Moonlight dalla pagina (intent:// o moonlight://): li gestisce l'app
            if (url.startsWith("intent:") || url.startsWith("moonlight:")) {
                openMoonlight();
                return true;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException ignored) {
                // schema non gestito
            }
            return true;
        }
    }

    /** Oggetto visibile da JavaScript come window.GameDockAndroid */
    private class Bridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return true;
        }

        @JavascriptInterface
        public boolean isTv() {
            return MainActivity.this.isTv();
        }

        @JavascriptInterface
        public String getVersion() {
            return versionName();
        }

        @JavascriptInterface
        public int getVersionCode() {
            return versionCode();
        }

        /** La pagina ha trovato una versione più nuova sul PC: scarica e installa. */
        @JavascriptInterface
        public void installUpdate() {
            main.post(MainActivity.this::downloadUpdate);
        }

        @JavascriptInterface
        public boolean openMoonlight() {
            main.post(MainActivity.this::openMoonlight);
            return getPackageManager().getLaunchIntentForPackage(MOONLIGHT_PACKAGE) != null
                    || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                    && getPackageManager().getLeanbackLaunchIntentForPackage(MOONLIGHT_PACKAGE) != null);
        }

        /** Streaming diretto: GameDock passa l'identità del PC (da Sunshine) e l'app da avviare. */
        @JavascriptInterface
        public void startStream(String uuid, String pcName, String appName) {
            main.post(() -> MainActivity.this.startStream(uuid, pcName, appName));
        }

        /** La pagina comunica MAC e broadcast del PC quando è online: servono per accenderlo dopo. */
        @JavascriptInterface
        public void saveWakeInfo(String mac, String broadcast) {
            if (mac == null || mac.replaceAll("[^0-9A-Fa-f]", "").length() != 12) return;
            prefs.edit()
                    .putString("mac", mac)
                    .putString("broadcast", broadcast == null || broadcast.isEmpty() ? "255.255.255.255" : broadcast)
                    .apply();
        }

        @JavascriptInterface
        public boolean wake(String mac, String broadcast) {
            saveWakeInfo(mac, broadcast);
            final String m = mac;
            final String b = broadcast;
            executor.execute(() -> sendMagicPacket(m, b));
            return true;
        }

        @JavascriptInterface
        public void changeServer() {
            main.post(() -> showSetup(""));
        }
    }

    // ------------------------------------------------------------------ tasti

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // Con GameDock aperto, i pulsanti del controller vanno solo alla pagina (Gamepad API):
        // così B non fa anche "Indietro" di Android, evitando un doppio ritorno.
        if (screen == Screen.NONE && isGamepadButton(event)) {
            web.dispatchKeyEvent(event);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private static boolean isGamepadButton(KeyEvent event) {
        boolean fromGamepad = (event.getSource() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD;
        return fromGamepad && KeyEvent.isGamepadButton(event.getKeyCode());
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (screen == Screen.SETUP && !server().isEmpty()) {
            checkAndLoad();
            return;
        }
        if (screen == Screen.NONE && web.canGoBack()) {
            web.goBack();       // la pagina gestisce la navigazione interna (history)
            return;
        }
        super.onBackPressed();
    }
}
