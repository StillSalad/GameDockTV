"""
GameDock Agent - persistenza su disco.

config.json         -> impostazioni dell'Agent (porta, token, nome PC...)
games/library.json  -> giochi aggiunti a mano, preferiti, sessioni, copertine
games/covers/       -> copertine caricate dall'utente
"""

import json
import os
import secrets
import socket
import sys
import threading

if getattr(sys, "frozen", False):          # GameDockAgent.exe (PyInstaller)
    BASE_DIR = os.path.dirname(sys.executable)
    BUNDLE_DIR = getattr(sys, "_MEIPASS", BASE_DIR)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    BUNDLE_DIR = BASE_DIR

CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
GAMES_DIR = os.path.join(BASE_DIR, "games")
LIBRARY_PATH = os.path.join(GAMES_DIR, "library.json")
COVERS_DIR = os.path.join(GAMES_DIR, "covers")
LOG_PATH = os.path.join(BASE_DIR, "agent.log")
BRANDING_DIR = os.path.join(BASE_DIR, "branding")

# La webapp compilata: prima cerca accanto all'exe/script, poi dentro il bundle
WEB_DIR = os.path.join(BASE_DIR, "web")
if not os.path.isdir(WEB_DIR):
    WEB_DIR = os.path.join(BUNDLE_DIR, "web")

DEFAULT_CONFIG = {
    "pcName": socket.gethostname(),
    "host": "0.0.0.0",
    "port": 8765,
    "token": "",
    "lanOnly": True,
    "allowPower": True,
    "scan": {"steam": True, "ea": True, "epic": True, "ubisoft": True,
             "gog": True, "battlenet": True, "xbox": True, "rockstar": True},
    "wake": {"mac": "", "broadcast": "255.255.255.255", "port": 9},
    "streaming": {"sunshinePath": r"C:\Program Files\Sunshine\sunshine.exe"},
    "console": {"focusOnExit": True, "homeButton": True, "kiosk": True, "hideLaunchers": True},
    "onlineCovers": {"enabled": True},
    "sunshine": {"url": "https://localhost:47990", "username": "", "password": "", "autoSync": True,
                 "autoResolution": True},
}

DEFAULT_LIBRARY = {"manual": [], "favorites": [], "hidden": [], "sessions": {}, "covers": {}, "coverMisses": {}, "sunshineApps": [], "profiles": [], "history": [], "tags": {}, "autoTags": {}, "tagMisses": {}, "firstSeen": {}, "collections": []}

# Alfabeto senza caratteri ambigui (0/O, 1/I): il token si digita con un telecomando
_TOKEN_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

_lock = threading.RLock()


def generate_token():
    raw = "".join(secrets.choice(_TOKEN_ALPHABET) for _ in range(8))
    return f"GD-{raw[:4]}-{raw[4:]}"


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return json.loads(json.dumps(default))
    except (json.JSONDecodeError, OSError):
        # File corrotto: lo conserviamo come .bak e ripartiamo dai default
        try:
            os.replace(path, path + ".bak")
        except OSError:
            pass
        return json.loads(json.dumps(default))


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _merge(defaults, values):
    out = {}
    for key, default in defaults.items():
        value = values.get(key, default) if isinstance(values, dict) else default
        if isinstance(default, dict) and default:
            # sezione con chiavi note (es. "scan"): unisce ricorsivamente
            out[key] = _merge(default, value if isinstance(value, dict) else {})
        elif isinstance(default, dict):
            # dizionario libero (es. "sessions", "covers"): tiene tutto ciò che è salvato
            out[key] = value if isinstance(value, dict) else {}
        else:
            out[key] = value
    return out


def load_config():
    with _lock:
        cfg = _merge(DEFAULT_CONFIG, _read_json(CONFIG_PATH, {}))
        if not cfg["pcName"]:
            cfg["pcName"] = socket.gethostname()
        if not cfg["token"]:
            cfg["token"] = generate_token()
        _write_json(CONFIG_PATH, cfg)
        return cfg


def save_config(cfg):
    with _lock:
        _write_json(CONFIG_PATH, cfg)


def load_library():
    with _lock:
        return _merge(DEFAULT_LIBRARY, _read_json(LIBRARY_PATH, {}))


def update_library(mutator):
    """Legge, modifica e salva la libreria in modo atomico. Ritorna il risultato del mutator."""
    with _lock:
        lib = load_library()
        result = mutator(lib)
        _write_json(LIBRARY_PATH, lib)
        return result
