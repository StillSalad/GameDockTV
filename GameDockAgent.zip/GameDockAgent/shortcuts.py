"""
GameDock Agent - collegamenti di Windows (icona GameDock).

Crea l'icona "GameDock" sul desktop, nel menu Start e (facoltativo) in Esecuzione
automatica. L'icona avvia l'Agent se non è in esecuzione e apre il launcher a
schermo intero (agent.py --open-console), senza finestre del prompt.
Usa PowerShell + WScript.Shell, presenti in ogni Windows: nessuna dipendenza.
"""

import json
import logging
import os
import subprocess
import sys

import storage

log = logging.getLogger("gamedock.shortcuts")
IS_WINDOWS = sys.platform.startswith("win")
LINK_NAME = "GameDock.lnk"
LEGACY_NAMES = ("GameDock Console.lnk",)      # collegamenti creati dalle versioni precedenti
KINDS = {"desktop": "Desktop", "startMenu": "Programs", "autostart": "Startup"}

_folders_cache = {}


class ShortcutError(Exception):
    pass


def _powershell(script, env=None, timeout=20):
    result = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True, text=True, errors="ignore", timeout=timeout,
        env={**os.environ, **(env or {})}, creationflags=subprocess.CREATE_NO_WINDOW,
    )
    if result.returncode != 0:
        raise ShortcutError(result.stderr.strip() or "PowerShell non ha completato l'operazione.")
    return result.stdout


def _folders():
    """Cartelle reali di Desktop, menu Start e Esecuzione automatica (anche se spostate su OneDrive)."""
    if not _folders_cache:
        script = ("$o=@{};" + ";".join(
            f"$o['{kind}']=[Environment]::GetFolderPath('{name}')" for kind, name in KINDS.items())
            + ";$o | ConvertTo-Json -Compress")
        _folders_cache.update(json.loads(_powershell(script)))
    return _folders_cache


def launcher_command():
    """(eseguibile, argomenti) che l'icona deve lanciare."""
    if getattr(sys, "frozen", False):                 # GameDockAgent.exe
        return sys.executable, "--open-console"
    python_dir = os.path.dirname(sys.executable)
    pythonw = os.path.join(python_dir, "pythonw.exe")  # nessuna finestra del prompt
    target = pythonw if os.path.isfile(pythonw) else sys.executable
    return target, f'"{os.path.join(storage.BASE_DIR, "agent.py")}" --open-console'


def icon_path():
    ico = os.path.join(storage.BASE_DIR, "gamedock.ico")
    if not os.path.isfile(ico):
        ico = os.path.join(storage.BUNDLE_DIR, "gamedock.ico")
    return ico


def _link_path(kind):
    if kind not in KINDS:
        raise ShortcutError("Tipo di collegamento non valido.")
    return os.path.join(_folders()[kind], LINK_NAME)


def status():
    if not IS_WINDOWS:
        return {"supported": False, **{k: False for k in KINDS}}
    try:
        return {"supported": True, **{k: os.path.isfile(_link_path(k)) for k in KINDS}}
    except (ShortcutError, OSError, ValueError, subprocess.SubprocessError) as e:
        log.warning("Stato collegamenti non disponibile: %s", e)
        return {"supported": False, **{k: False for k in KINDS}}


def set_shortcut(kind, enabled):
    if not IS_WINDOWS:
        raise ShortcutError("I collegamenti si possono creare solo su Windows.")
    path = _link_path(kind)
    folder = os.path.dirname(path)
    for legacy in LEGACY_NAMES:                      # evita icone doppie
        try:
            os.remove(os.path.join(folder, legacy))
        except OSError:
            pass
    if not enabled:
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
        log.info("Collegamento rimosso: %s", path)
        return
    target, args = launcher_command()
    script = (
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:GD_LNK);"
        "$s.TargetPath=$env:GD_TARGET;$s.Arguments=$env:GD_ARGS;$s.WorkingDirectory=$env:GD_WD;"
        "$s.IconLocation=$env:GD_ICON;$s.Description='GameDock - il tuo gaming, direttamente sulla TV';"
        "$s.Save()"
    )
    _powershell(script, env={
        "GD_LNK": path, "GD_TARGET": target, "GD_ARGS": args,
        "GD_WD": storage.BASE_DIR, "GD_ICON": icon_path() + ",0",
    })
    log.info("Collegamento creato: %s", path)


def apply(changes):
    """changes: {"desktop": True, "startMenu": True, "autostart": False}"""
    for kind, enabled in changes.items():
        if kind in KINDS:
            set_shortcut(kind, bool(enabled))
    return status()
