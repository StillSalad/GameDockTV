"""
GameDock Agent - rilevamento dei giochi installati.

Legge solo file e chiavi di registro locali. Non usa credenziali, non contatta
nessun servizio online. Ogni scanner restituisce una lista di dizionari:

{
  "id": "steam-1234",
  "name": "...",
  "platform": "Steam" | "EA" | "Epic" | "Ubisoft" | "Altro",
  "path": "cartella di installazione",
  "executable": "percorso .exe" o None,
  "launch": {"type": "uri", "uri": "steam://..."} | {"type": "exe", "path": "...", "args": ""},
  "coverFile": "copertina locale" o None,
  "lastPlayed": timestamp o None,
  "source": "auto"
}
"""

import glob
import json
import logging
import os
import re
import sys
import time

try:
    import winreg  # disponibile solo su Windows
except ImportError:
    winreg = None

log = logging.getLogger("gamedock.scanner")

# Strumenti Steam che non sono giochi
STEAM_EXCLUDED_IDS = {"228980", "250820", "1070560", "1391110", "1628350", "1826330", "1493710"}
STEAM_EXCLUDED_WORDS = ("redistributable", "steam linux runtime", "proton", "steamworks")

EXE_BLACKLIST = ("unins", "crash", "setup", "cleanup", "touchup", "redist", "vcredist",
                 "dxsetup", "launcherhelper", "report", "installer", "eac", "easyanticheat")


def slugify(value):
    return re.sub(r"[^a-z0-9]+", "-", str(value).lower()).strip("-")[:60] or "game"


# ---------------------------------------------------------------- registro --

def _reg_open(root, path, view=0):
    if winreg is None:
        return None
    try:
        return winreg.OpenKey(root, path, 0, winreg.KEY_READ | view)
    except OSError:
        return None


def _reg_value(key, name):
    try:
        return winreg.QueryValueEx(key, name)[0]
    except OSError:
        return None


def _reg_subkeys(key):
    i = 0
    while True:
        try:
            yield winreg.EnumKey(key, i)
        except OSError:
            return
        i += 1


def _reg_get(root_name, path, name):
    if winreg is None:
        return None
    root = getattr(winreg, root_name)
    for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
        key = _reg_open(root, path, view)
        if key:
            value = _reg_value(key, name)
            winreg.CloseKey(key)
            if value:
                return value
    return None


# ------------------------------------------------------------------- Steam --

def parse_vdf(text):
    """Parser minimale per il formato KeyValues di Valve (.vdf / .acf)."""
    tokens = re.findall(r'"((?:[^"\\]|\\.)*)"|([{}])', text)

    def unescape(s):
        return s.replace("\\\\", "\\").replace('\\"', '"')

    def parse(i):
        obj = {}
        while i < len(tokens):
            string, brace = tokens[i]
            if brace == "}":
                return obj, i + 1
            if brace == "{":          # graffa inattesa: la saltiamo
                i += 1
                continue
            key = unescape(string)
            i += 1
            if i >= len(tokens):
                break
            string2, brace2 = tokens[i]
            if brace2 == "{":
                value, i = parse(i + 1)
            else:
                value, i = unescape(string2), i + 1
            obj[key] = value
        return obj, i

    return parse(0)[0]


def _steam_root():
    candidates = [
        _reg_get("HKEY_CURRENT_USER", r"Software\Valve\Steam", "SteamPath"),
        _reg_get("HKEY_LOCAL_MACHINE", r"SOFTWARE\Valve\Steam", "InstallPath"),
        r"C:\Program Files (x86)\Steam",
        r"C:\Program Files\Steam",
    ]
    for path in candidates:
        if path and os.path.isdir(os.path.join(path, "steamapps")):
            return os.path.normpath(path)
    return None


def _steam_libraries(root):
    libraries = [root]
    vdf_path = os.path.join(root, "steamapps", "libraryfolders.vdf")
    try:
        with open(vdf_path, "r", encoding="utf-8", errors="ignore") as f:
            data = parse_vdf(f.read())
        folders = data.get("libraryfolders") or data.get("LibraryFolders") or {}
        for value in folders.values():
            path = value.get("path") if isinstance(value, dict) else value
            if isinstance(path, str) and os.path.isdir(os.path.join(path, "steamapps")):
                libraries.append(os.path.normpath(path))
    except OSError:
        pass
    seen, unique = set(), []
    for lib in libraries:
        key = os.path.normcase(lib)
        if key not in seen:
            seen.add(key)
            unique.append(lib)
    return unique


def _steam_cover(root, appid):
    cache = os.path.join(root, "appcache", "librarycache")
    patterns = [
        os.path.join(cache, f"{appid}_library_600x900.jpg"),
        os.path.join(cache, appid, "library_600x900.jpg"),
        os.path.join(cache, appid, "*", "library_600x900.jpg"),
        os.path.join(cache, f"{appid}_header.jpg"),
        os.path.join(cache, appid, "header.jpg"),
        os.path.join(cache, appid, "*", "header.jpg"),
    ]
    for pattern in patterns:
        found = glob.glob(pattern)
        if found:
            return found[0]
    return None


def scan_steam():
    root = _steam_root()
    if not root:
        return []
    games = []
    for library in _steam_libraries(root):
        for manifest in glob.glob(os.path.join(library, "steamapps", "appmanifest_*.acf")):
            try:
                with open(manifest, "r", encoding="utf-8", errors="ignore") as f:
                    state = parse_vdf(f.read()).get("AppState", {})
            except OSError:
                continue
            appid = str(state.get("appid", "")).strip()
            name = state.get("name", "").strip()
            if not appid or not name or appid in STEAM_EXCLUDED_IDS:
                continue
            if any(word in name.lower() for word in STEAM_EXCLUDED_WORDS):
                continue
            install = os.path.join(library, "steamapps", "common", state.get("installdir", ""))
            last = state.get("LastPlayed")
            steam_exe = os.path.join(root, "steam.exe")
            games.append({
                "id": f"steam-{appid}",
                "name": name,
                "platform": "Steam",
                "path": install,
                "executable": None,
                # -silent: Steam non apre la finestra della libreria sopra GameDock
                "launch": {"type": "steam", "exe": steam_exe, "appid": appid,
                           "uri": f"steam://rungameid/{appid}"},
                "coverFile": _steam_cover(root, appid),
                "lastPlayed": int(last) if str(last).isdigit() and int(last) > 0 else None,
                "source": "auto",
                "appId": appid,
            })
    return games


# -------------------------------------------------------------------- Epic --

def scan_epic():
    program_data = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
    folder = os.path.join(program_data, "Epic", "EpicGamesLauncher", "Data", "Manifests")
    games = []
    for item in glob.glob(os.path.join(folder, "*.item")):
        try:
            with open(item, "r", encoding="utf-8", errors="ignore") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        categories = [c.lower() for c in data.get("AppCategories", [])]
        if categories and "games" not in categories:
            continue
        name = data.get("DisplayName")
        app = data.get("AppName")
        namespace = data.get("CatalogNamespace")
        item_id = data.get("CatalogItemId")
        location = data.get("InstallLocation", "")
        if not (name and app and namespace and item_id):
            continue
        exe = data.get("LaunchExecutable")
        exe_path = os.path.join(location, exe) if exe else None
        uri = (f"com.epicgames.launcher://apps/{namespace}%3A{item_id}%3A{app}"
               "?action=launch&silent=true")
        games.append({
            "id": f"epic-{slugify(app)}",
            "name": name,
            "platform": "Epic",
            "path": location,
            "executable": exe_path,
            "launch": {"type": "uri", "uri": uri},
            "coverFile": None,
            "lastPlayed": None,
            "source": "auto",
        })
    return games


# ----------------------------------------------------------------- Ubisoft --

def scan_ubisoft():
    if winreg is None:
        return []
    games = []
    key = _reg_open(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Ubisoft\Launcher\Installs", winreg.KEY_WOW64_32KEY)
    if not key:
        return []
    for game_id in _reg_subkeys(key):
        sub = _reg_open(key, game_id)
        if not sub:
            continue
        install = _reg_value(sub, "InstallDir")
        winreg.CloseKey(sub)
        if not install or not os.path.isdir(install):
            continue
        name = os.path.basename(os.path.normpath(install))
        games.append({
            "id": f"ubisoft-{game_id}",
            "name": name,
            "platform": "Ubisoft",
            "path": os.path.normpath(install),
            "executable": None,
            "launch": {"type": "uri", "uri": f"uplay://launch/{game_id}/0"},
            "coverFile": None,
            "lastPlayed": None,
            "source": "auto",
        })
    winreg.CloseKey(key)
    return games


# ---------------------------------------------------------------------- EA --

def _best_exe(folder):
    """Sceglie l'eseguibile più probabile del gioco (il più grande, esclusi tool e installer)."""
    best, best_size = None, 0
    try:
        entries = list(os.scandir(folder))
    except OSError:
        return None
    for entry in entries:
        name = entry.name.lower()
        if not name.endswith(".exe") or any(bad in name for bad in EXE_BLACKLIST):
            continue
        try:
            size = entry.stat().st_size
        except OSError:
            continue
        if size > best_size:
            best, best_size = entry.path, size
    return best


def _clean_icon_path(value):
    if not value:
        return None
    path = value.split(",")[0].strip().strip('"')
    if path.lower().endswith(".exe") and os.path.isfile(path) \
            and not any(bad in os.path.basename(path).lower() for bad in EXE_BLACKLIST):
        return path
    return None


def scan_ea():
    if winreg is None:
        return []
    found = {}
    uninstall_roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_64KEY),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_32KEY),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", 0),
    ]
    for root, path, view in uninstall_roots:
        key = _reg_open(root, path, view)
        if not key:
            continue
        for name in _reg_subkeys(key):
            sub = _reg_open(key, name)
            if not sub:
                continue
            publisher = str(_reg_value(sub, "Publisher") or "")
            display = str(_reg_value(sub, "DisplayName") or "").strip()
            location = _reg_value(sub, "InstallLocation")
            icon = _reg_value(sub, "DisplayIcon")
            winreg.CloseKey(sub)
            if "electronic arts" not in publisher.lower() or not display:
                continue
            if any(w in display.lower() for w in ("ea app", "ea desktop", "origin", "ea anticheat")):
                continue
            if not location or not os.path.isdir(location):
                continue
            exe = _clean_icon_path(icon) or _best_exe(location)
            found[os.path.normcase(os.path.normpath(location))] = (display, location, exe)
        winreg.CloseKey(key)

    # Vecchio formato Origin/EA: HKLM\SOFTWARE\EA Games\<gioco>
    key = _reg_open(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\EA Games", winreg.KEY_WOW64_32KEY)
    if key:
        for name in _reg_subkeys(key):
            sub = _reg_open(key, name)
            if not sub:
                continue
            location = _reg_value(sub, "Install Dir")
            display = _reg_value(sub, "DisplayName") or name
            winreg.CloseKey(sub)
            if location and os.path.isdir(location):
                norm = os.path.normcase(os.path.normpath(location))
                if norm not in found:
                    found[norm] = (display, location, _best_exe(location))
        winreg.CloseKey(key)

    games = []
    for display, location, exe in found.values():
        if not exe:
            continue
        games.append({
            "id": f"ea-{slugify(display)}",
            "name": display,
            "platform": "EA",
            "path": os.path.normpath(location),
            "executable": exe,
            "launch": {"type": "exe", "path": exe, "args": ""},
            "coverFile": None,
            "lastPlayed": None,
            "source": "auto",
        })
    return games


# --------------------------------------------------------------------- GOG --

def scan_gog():
    """GOG Galaxy (e installer GOG offline): registro HKLM > SOFTWARE > GOG.com > Games."""
    if winreg is None:
        return []
    games = []
    key = _reg_open(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\GOG.com\Games", winreg.KEY_WOW64_32KEY)
    if not key:
        return []
    for game_id in _reg_subkeys(key):
        sub = _reg_open(key, game_id)
        if not sub:
            continue
        name = _reg_value(sub, "gameName") or _reg_value(sub, "GAMENAME")
        exe = _reg_value(sub, "exe") or _reg_value(sub, "EXE")
        path = _reg_value(sub, "path") or _reg_value(sub, "PATH")
        args = _reg_value(sub, "launchParam") or ""
        winreg.CloseKey(sub)
        if not name or not exe or not os.path.isfile(exe):
            continue
        games.append({
            "id": f"gog-{game_id}",
            "name": name,
            "platform": "GOG",
            "path": os.path.normpath(path) if path else os.path.dirname(exe),
            "executable": exe,
            "launch": {"type": "exe", "path": exe, "args": args},
            "coverFile": None,
            "lastPlayed": None,
            "source": "auto",
        })
    winreg.CloseKey(key)
    return games


# --------------------------------------------------------------- Battle.net --

# uid dell'uninstaller Blizzard -> codice prodotto per "Battle.net.exe --exec=launch <codice>"
BATTLENET_CODES = {
    "prometheus": "Pro", "fenris": "Fen", "diablo3": "D3", "osi": "OSI", "anbs": "ANBS",
    "wow": "WoW", "wow_classic": "WoWC", "hs_beta": "WTCG", "heroes": "Hero", "s2": "S2",
    "s1": "S1", "w3": "W3", "odin": "ODIN", "zeus": "ZEUS", "fore": "FORE", "auks": "AUKS",
    "lazarus": "LAZR", "viper": "VIPR", "wlby": "WLBY", "rtro": "RTRO",
}


def _battlenet_exe():
    for base in (os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("ProgramFiles", r"C:\Program Files")):
        exe = os.path.join(base, "Battle.net", "Battle.net.exe")
        if os.path.isfile(exe):
            return exe
    return None


def scan_battlenet():
    """Giochi installati con Battle.net (Call of Duty, Diablo, Overwatch, WoW...).
    Li riconosce dall'uninstaller di Blizzard registrato in Windows."""
    if winreg is None:
        return []
    client = _battlenet_exe()
    games, seen = [], set()
    for root, path, view in (
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_32KEY),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", winreg.KEY_WOW64_64KEY),
    ):
        key = _reg_open(root, path, view)
        if not key:
            continue
        for name in _reg_subkeys(key):
            sub = _reg_open(key, name)
            if not sub:
                continue
            uninstall = str(_reg_value(sub, "UninstallString") or "")
            display = str(_reg_value(sub, "DisplayName") or "").strip()
            location = _reg_value(sub, "InstallLocation")
            icon = _reg_value(sub, "DisplayIcon")
            winreg.CloseKey(sub)
            if "Blizzard Uninstaller" not in uninstall and "Battle.net\\Agent" not in uninstall:
                continue
            if not display or display.lower().startswith("battle.net"):
                continue
            uid = re.search(r"--uid=([A-Za-z0-9_]+)", uninstall)
            uid = uid.group(1).lower() if uid else ""
            if uid in seen:
                continue
            seen.add(uid or display)
            code = BATTLENET_CODES.get(uid) or (uid.upper() if uid else None)
            exe = _clean_icon_path(icon) or (_best_exe(location) if location and os.path.isdir(location) else None)
            if client and code:
                launch = {"type": "battlenet", "exe": client, "code": code}
            elif exe:
                launch = {"type": "exe", "path": exe, "args": ""}
            else:
                continue
            games.append({
                "id": f"battlenet-{slugify(uid or display)}",
                "name": display,
                "platform": "Battle.net",
                "path": os.path.normpath(location) if location else None,
                "executable": exe,
                "launch": launch,
                "coverFile": None,
                "lastPlayed": None,
                "source": "auto",
            })
        winreg.CloseKey(key)
    return games


# ------------------------------------------------------------------ Rockstar --

ROCKSTAR_EXES = {
    "grand theft auto v": "PlayGTAV.exe", "grand theft auto v enhanced": "PlayGTAV.exe",
    "red dead redemption 2": "RDR2.exe", "red dead redemption": "RDR.exe",
    "l.a. noire": "LANoire.exe", "max payne 3": "MaxPayne3.exe", "bully": "Bully.exe",
}
ROCKSTAR_SKIP = ("launcher", "social club", "rockstar games social club")


def scan_rockstar():
    """Rockstar Games Launcher: registro HKLM > SOFTWARE > Rockstar Games > (gioco) > InstallFolder."""
    if winreg is None:
        return []
    games = []
    key = _reg_open(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Rockstar Games", winreg.KEY_WOW64_32KEY)
    if not key:
        return []
    for name in _reg_subkeys(key):
        if name.lower() in ROCKSTAR_SKIP:
            continue
        sub = _reg_open(key, name)
        if not sub:
            continue
        folder = _reg_value(sub, "InstallFolder")      # solo le copie del launcher Rockstar
        winreg.CloseKey(sub)
        if not folder or not os.path.isdir(folder):
            continue
        preferred = ROCKSTAR_EXES.get(name.lower())
        exe = os.path.join(folder, preferred) if preferred else None
        if not exe or not os.path.isfile(exe):
            exe = _best_exe(folder)
        if not exe:
            continue
        games.append({
            "id": f"rockstar-{slugify(name)}",
            "name": name,
            "platform": "Rockstar",
            "path": os.path.normpath(folder),
            "executable": exe,
            "launch": {"type": "exe", "path": exe, "args": ""},
            "coverFile": None,
            "lastPlayed": None,
            "source": "auto",
        })
    winreg.CloseKey(key)
    return games


# ---------------------------------------------------------- Xbox / Game Pass --

_XBOX_PS = r"""
$ErrorActionPreference = 'SilentlyContinue'
$out = @()
foreach ($p in Get-AppxPackage) {
  if ($p.IsFramework -or -not $p.InstallLocation) { continue }
  $cfg = Join-Path $p.InstallLocation 'MicrosoftGame.config'
  if (-not (Test-Path $cfg)) { continue }
  $m = Get-AppxPackageManifest $p
  $app = @($m.Package.Applications.Application)[0].Id
  if (-not $app) { continue }
  $out += [pscustomobject]@{ family = $p.PackageFamilyName; location = $p.InstallLocation; app = $app; name = $p.Name }
}
ConvertTo-Json -InputObject @($out) -Compress
"""


def parse_microsoft_game_config(path):
    """Legge nome visualizzato, eseguibile e logo da MicrosoftGame.config (giochi Xbox/Game Pass)."""
    import xml.etree.ElementTree as ET
    root = ET.parse(path).getroot()

    def strip(tag):
        return tag.split("}", 1)[-1]

    info = {"name": None, "exe": None, "logo": None}
    for el in root.iter():
        tag = strip(el.tag)
        if tag == "ShellVisuals":
            name = el.get("DefaultDisplayName")
            if name and not name.startswith("ms-resource"):
                info["name"] = name
            info["logo"] = el.get("Square480x480Logo") or el.get("Square150x150Logo") or el.get("StoreLogo")
        elif tag == "Executable" and not info["exe"]:
            info["exe"] = el.get("Name")
    return info


def _pretty_package_name(name):
    base = name.split(".", 1)[-1] if "." in name else name
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", base).replace("_", " ").strip()


def scan_xbox():
    if not sys.platform.startswith("win"):
        return []
    import subprocess
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", _XBOX_PS],
                             capture_output=True, text=True, errors="ignore", timeout=60,
                             creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
        packages = json.loads(out) if out else []
    except (OSError, ValueError, subprocess.SubprocessError):
        return []
    if isinstance(packages, dict):
        packages = [packages]
    games = []
    for p in packages:
        location = p.get("location")
        family, app = p.get("family"), p.get("app")
        if not (location and family and app):
            continue
        try:
            info = parse_microsoft_game_config(os.path.join(location, "MicrosoftGame.config"))
        except Exception:
            info = {"name": None, "exe": None, "logo": None}
        logo = os.path.join(location, info["logo"]) if info.get("logo") else None
        exe = os.path.join(location, info["exe"]) if info.get("exe") else None
        games.append({
            "id": f"xbox-{slugify(family)}",
            "name": info.get("name") or _pretty_package_name(p.get("name", family)),
            "platform": "Xbox",
            "path": location,
            "executable": exe if exe and os.path.isfile(exe) else None,
            "launch": {"type": "shell", "family": family, "app": app},
            "coverFile": logo if logo and os.path.isfile(logo) else None,
            "lastPlayed": None,
            "source": "auto",
        })
    return games


# ------------------------------------------------------------------ tutto --

SCANNERS = {"steam": scan_steam, "ea": scan_ea, "epic": scan_epic, "ubisoft": scan_ubisoft,
            "gog": scan_gog, "battlenet": scan_battlenet, "xbox": scan_xbox, "rockstar": scan_rockstar}

_cache = {"games": [], "time": 0, "counts": {}}


def scan_all(scan_config, force=False, max_age=300):
    """Scansiona le piattaforme abilitate. Il risultato resta in cache per max_age secondi."""
    if not force and _cache["time"] and time.time() - _cache["time"] < max_age:
        return _cache["games"]
    games, counts = [], {}
    for name, scanner in SCANNERS.items():
        if not scan_config.get(name, True):
            counts[name] = None
            continue
        try:
            result = scanner()
        except Exception:  # uno scanner che fallisce non deve bloccare gli altri
            log.exception("Scanner %s fallito", name)
            result = []
        counts[name] = len(result)
        games.extend(result)
    # Niente doppioni: se due launcher indicano la stessa cartella vince il primo (Steam, EA, Epic...)
    unique, seen_paths = [], set()
    for g in games:
        key = os.path.normcase(os.path.normpath(g["path"])) if g.get("path") else None
        if key and key in seen_paths:
            continue
        if key:
            seen_paths.add(key)
        unique.append(g)
    games = unique
    _cache.update(games=games, time=time.time(), counts=counts)
    log.info("Scansione completata: %s", counts)
    return games


def last_counts():
    return dict(_cache["counts"])
