package com.lollomarta.gamedock;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Passa all'installatore di Android l'APK scaricato (cache/update.apk) tramite un URI content://.
 * Sostituisce FileProvider senza bisogno di librerie esterne. Espone solo quel file, in sola lettura.
 */
public class ApkProvider extends ContentProvider {

    public static final String AUTHORITY = "com.lollomarta.gamedock.apk";
    public static final String FILE_NAME = "update.apk";
    public static final Uri URI = Uri.parse("content://" + AUTHORITY + "/" + FILE_NAME);
    private static final String MIME = "application/vnd.android.package-archive";

    static File apkFile(android.content.Context context) {
        return new File(context.getCacheDir(), FILE_NAME);
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!FILE_NAME.equals(uri.getLastPathSegment())) throw new FileNotFoundException();
        File file = apkFile(getContext());
        if (!file.exists()) throw new FileNotFoundException();
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        return MIME;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File file = apkFile(getContext());
        MatrixCursor cursor = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
        cursor.addRow(new Object[]{"GameDock.apk", file.length()});
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
