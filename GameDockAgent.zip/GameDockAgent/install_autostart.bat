@echo off
rem Crea un collegamento nella cartella Esecuzione automatica di Windows
rem che avvia l'Agent in background (pythonw, senza finestra) a ogni accesso.
cd /d "%~dp0"
set "PYW="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW (
  echo pythonw.exe non trovato. Installa Python da python.org spuntando "Add python.exe to PATH".
  pause
  exit /b 1
)
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%STARTUP%\GameDock Agent.lnk');" ^
  "$s.TargetPath='%PYW%';$s.Arguments='\"%~dp0agent.py\"';$s.WorkingDirectory='%~dp0';" ^
  "$s.Description='GameDock Agent';$s.Save()"
echo Avvio automatico attivato. L'Agent partira' in background a ogni accesso a Windows.
echo Per avviarlo subito senza riavviare:
start "" "%PYW%" "%~dp0agent.py"
echo Agent avviato in background. Il codice di accesso e' in config.json (campo "token").
pause
