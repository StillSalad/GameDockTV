"""
GameDock Agent - copertine automatiche (solo per uso personale/test).

Cerca il gioco nel negozio di Steam per nome e scarica la copertina verticale
(library_600x900) in games/covers/auto-<id>.jpg. Funziona anche per giochi
installati con altri launcher, se il gioco esiste anche su Steam.

Si disattiva da config.json ("onlineCovers": {"enabled": false}) o dalle
Impostazioni di GameDock; "Rimuovi copertine scaricate" cancella tutti i file.
"""

import difflib
import json
import logging
import os
import re
import threading
import time
import urllib.parse
import urllib.request

import storage

log = logging.getLogger("gamedock.covers")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) GameDockAgent/1.0"
MATCH_THRESHOLD = 0.72        # somiglianza minima tra nome del gioco e risultato Steam
RETRY_AFTER = 7 * 86400       # un gioco non trovato viene ricercato dopo 7 giorni
AUTO_PREFIX = "auto:"

_running = threading.Lock()


def _get(url, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as res:  # noqa: S310 - solo URL Steam fissi
        return res.read()


def _norm(name):
    name = re.sub(r"[®™©]", "", name.lower())
    return re.sub(r"[^a-z0-9]+", " ", name).strip()


def find_steam_app(name):
    """AppID Steam più somigliante al nome, oppure None."""
    query = urllib.parse.urlencode({"term": name, "l": "italian", "cc": "IT"})
    data = json.loads(_get(f"https://store.steampowered.com/api/storesearch/?{query}"))
    target = _norm(name)
    best_id, best_score = None, 0.0
    for item in data.get("items", []):
        if item.get("type") != "app":
            continue
        score = difflib.SequenceMatcher(None, target, _norm(item.get("name", ""))).ratio()
        if score > best_score:
            best_id, best_score = item.get("id"), score
    if best_id and best_score >= MATCH_THRESHOLD:
        return int(best_id)
    return None


def _is_jpeg(data):
    return data[:3] == b"\xff\xd8\xff" and len(data) > 4000


def download_steam_cover(appid):
    """Scarica la copertina verticale; se manca usa l'immagine orizzontale del negozio."""
    candidates = [
        f"https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{appid}/library_600x900_2x.jpg",
        f"https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/{appid}/library_600x900.jpg",
        f"https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/library_600x900.jpg",
    ]
    for url in candidates:
        try:
            data = _get(url)
            if _is_jpeg(data):
                return data
        except Exception:  # 404 o rete: proviamo il prossimo
            continue
    try:
        details = json.loads(_get(f"https://store.steampowered.com/api/appdetails?appids={appid}"))
        header = details.get(str(appid), {}).get("data", {}).get("header_image")
        if header:
            data = _get(header)
            if _is_jpeg(data):
                return data
    except Exception:
        pass
    return None


def _save(game_id, data):
    os.makedirs(storage.COVERS_DIR, exist_ok=True)
    safe = re.sub(r"[^a-z0-9-]+", "-", game_id.lower())[:80]
    filename = f"auto-{safe}.jpg"
    with open(os.path.join(storage.COVERS_DIR, filename), "wb") as f:
        f.write(data)
    return filename


def fetch_missing(games, force=False):
    """Cerca le copertine dei giochi che non ne hanno una. Ritorna quante ne ha trovate.
    games: lista di (game_id, name, steam_appid_or_None, has_cover)."""
    if not _running.acquire(blocking=False):
        return {"found": 0, "busy": True}
    found, missed = 0, 0
    try:
        lib = storage.load_library()
        misses = lib.get("coverMisses", {})
        for game_id, name, appid, has_cover in games:
            if has_cover:
                continue
            if not force and time.time() - misses.get(game_id, 0) < RETRY_AFTER:
                continue
            try:
                appid = appid or find_steam_app(name)
                data = download_steam_cover(appid) if appid else None
            except Exception as e:
                log.info("Copertina non disponibile per %s: %s", name, e)
                data = None
            if data:
                filename = _save(game_id, data)

                def ok(lib, gid=game_id, fn=filename):
                    lib["covers"][gid] = AUTO_PREFIX + fn
                    lib.setdefault("coverMisses", {}).pop(gid, None)
                storage.update_library(ok)
                found += 1
            else:
                def miss(lib, gid=game_id):
                    lib.setdefault("coverMisses", {})[gid] = int(time.time())
                storage.update_library(miss)
                missed += 1
            time.sleep(0.25)          # gentile con i server di Steam
        log.info("Copertine automatiche: %s trovate, %s non trovate", found, missed)
        return {"found": found, "missed": missed, "busy": False}
    finally:
        _running.release()


def clear_auto():
    """Elimina tutte le copertine scaricate automaticamente (prima di pubblicare)."""
    removed = 0

    def mutate(lib):
        nonlocal removed
        for gid, value in list(lib["covers"].items()):
            if value.startswith(AUTO_PREFIX):
                try:
                    os.remove(os.path.join(storage.COVERS_DIR, value[len(AUTO_PREFIX):]))
                except OSError:
                    pass
                del lib["covers"][gid]
                removed += 1
        lib["coverMisses"] = {}
    storage.update_library(mutate)
    return removed


def is_busy():
    return _running.locked()


# ------------------------------------------------------------------ categorie --

CATEGORIES = ("azione", "avventura", "sport", "strategia", "multiplayer", "puzzle", "pc", "mobile")
# Generi e caratteristiche del negozio Steam (identificativi numerici, uguali in tutte le lingue)
STEAM_GENRES = {1: "azione", 25: "avventura", 3: "avventura", 18: "sport", 9: "sport",
                2: "strategia", 28: "strategia", 4: "puzzle", 29: "multiplayer"}
STEAM_MULTI = {1, 9, 20, 27, 36, 38, 47, 48, 49}     # multigiocatore, cooperativa, PvP online...


def steam_tags(appid):
    data = json.loads(_get(f"https://store.steampowered.com/api/appdetails?appids={appid}&l=italian"))
    info = data.get(str(appid), {}).get("data") or {}
    tags = {STEAM_GENRES[int(g["id"])] for g in info.get("genres", []) if str(g.get("id", "")).isdigit()
            and int(g["id"]) in STEAM_GENRES}
    if any(int(c.get("id", 0)) in STEAM_MULTI for c in info.get("categories", [])):
        tags.add("multiplayer")
    if (info.get("platforms") or {}).get("windows"):
        tags.add("pc")
    return sorted(tags)


def fetch_tags(games, force=False):
    """Categorie automatiche dai generi di Steam. games: lista di (game_id, name, appid, has_tags)."""
    found = 0
    lib = storage.load_library()
    misses = lib.get("tagMisses", {})
    for game_id, name, appid, has_tags in games:
        if has_tags or (not force and time.time() - misses.get(game_id, 0) < RETRY_AFTER):
            continue
        tags = []
        try:
            appid = appid or find_steam_app(name)
            tags = steam_tags(appid) if appid else []
        except Exception as e:
            log.info("Categorie non disponibili per %s: %s", name, e)

        def save(lib, gid=game_id, t=tags):
            if t:
                lib.setdefault("autoTags", {})[gid] = t
                lib.setdefault("tagMisses", {}).pop(gid, None)
            else:
                lib.setdefault("tagMisses", {})[gid] = int(time.time())
        storage.update_library(save)
        found += 1 if tags else 0
        time.sleep(0.25)
    log.info("Categorie automatiche: %s giochi classificati", found)
    return found
