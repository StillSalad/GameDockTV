"""
GameDock Agent - modalità console sul PC.

- processes_in_folder(): trova i processi avviati da una cartella di gioco
  (serve per capire quando un gioco Steam/Epic/Ubisoft/EA si chiude).
- focus_gamedock(): riporta in primo piano la finestra di GameDock quando il gioco termina.
Usa solo ctypes (API di Windows), nessuna dipendenza esterna.
"""

import ctypes
import logging
import os
import sys
import threading
import time

log = logging.getLogger("gamedock.console")
IS_WINDOWS = sys.platform.startswith("win")

if IS_WINDOWS:
    from ctypes import wintypes

    _psapi = ctypes.WinDLL("psapi", use_last_error=True)
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    SW_RESTORE = 9
    VK_MENU = 0x12
    KEYEVENTF_KEYUP = 0x0002
    _WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


def _process_path(pid):
    handle = _kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(size.value)
        if _kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return buf.value
        return None
    finally:
        _kernel32.CloseHandle(handle)


def processes_in_folder(folder):
    """PID dei processi il cui eseguibile si trova dentro folder."""
    if not IS_WINDOWS or not folder or not os.path.isdir(folder):
        return set()
    prefix = os.path.normcase(os.path.normpath(folder)) + os.sep
    count = 4096
    while True:
        arr = (wintypes.DWORD * count)()
        needed = wintypes.DWORD()
        if not _psapi.EnumProcesses(arr, ctypes.sizeof(arr), ctypes.byref(needed)):
            return set()
        if needed.value < ctypes.sizeof(arr):
            break
        count *= 2
    pids = set()
    for pid in arr[: needed.value // ctypes.sizeof(wintypes.DWORD)]:
        if not pid:
            continue
        path = _process_path(pid)
        if path and os.path.normcase(path).startswith(prefix):
            pids.add(pid)
    return pids


def safe_watch_folder(folder):
    """Evita di sorvegliare cartelle troppo generiche (es. C:\\ o Program Files)."""
    if not folder:
        return False
    norm = os.path.normpath(folder)
    parts = [p for p in norm.replace("\\", "/").split("/") if p]
    generic = {"program files", "program files (x86)", "games", "steamapps", "common"}
    return len(parts) >= 2 and parts[-1].lower() not in generic


def _bring_to_front(hwnd):
    if _user32.IsIconic(hwnd):              # solo se è ridotta a icona, per non uscire dal fullscreen
        _user32.ShowWindow(hwnd, SW_RESTORE)
    # Windows impedisce ai processi in background di "rubare" il focus:
    # premere e rilasciare Alt sblocca SetForegroundWindow.
    _user32.keybd_event(VK_MENU, 0, 0, 0)
    _user32.SetForegroundWindow(hwnd)
    _user32.keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, 0)


def focus_game(pids):
    """Porta in primo piano la finestra principale di uno dei processi del gioco."""
    if not IS_WINDOWS or not pids:
        return False
    found = []

    def callback(hwnd, _):
        if not _user32.IsWindowVisible(hwnd) or not _user32.GetWindowTextLengthW(hwnd):
            return True
        pid = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids:
            found.append(hwnd)
            return False
        return True

    _user32.EnumWindows(_WNDENUMPROC(callback), 0)
    if not found:
        return False
    _bring_to_front(found[0])
    log.info("Gioco riportato in primo piano")
    return True


def focus_gamedock(delay=1.5):
    """Porta in primo piano la finestra il cui titolo inizia con "GameDock"."""
    if not IS_WINDOWS:
        return False
    time.sleep(delay)
    found = []

    def callback(hwnd, _):
        if not _user32.IsWindowVisible(hwnd):
            return True
        length = _user32.GetWindowTextLengthW(hwnd)
        if not length:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        _user32.GetWindowTextW(hwnd, buf, length + 1)
        if buf.value.startswith("GameDock"):
            found.append(hwnd)
            return False
        return True

    _user32.EnumWindows(_WNDENUMPROC(callback), 0)
    if not found:
        return False
    _bring_to_front(found[0])
    log.info("GameDock riportato in primo piano")
    return True


# ------------------------------------------------ protezione durante l'avvio --

# Finestre dei launcher che durante l'avvio non devono coprire GameDock
LAUNCHER_EXES = {
    "steam.exe", "steamwebhelper.exe", "eadesktop.exe", "eabackgroundservice.exe", "origin.exe",
    "epicgameslauncher.exe", "upc.exe", "ubisoftconnect.exe", "ubisoftgamelauncher.exe",
}
SW_MINIMIZE = 6


def _foreground_process():
    hwnd = _user32.GetForegroundWindow()
    if not hwnd:
        return None, None
    pid = wintypes.DWORD()
    _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    path = _process_path(pid.value) or ""
    return hwnd, os.path.basename(path).lower()


def guard_launch(folder, duration=60, max_minimize=8):
    """Durante l'avvio di un gioco (modalità console): tiene GameDock davanti ai launcher
    finché non compare il gioco, poi porta in primo piano il gioco.
    Il numero di interventi è limitato: se il launcher chiede davvero qualcosa
    (accesso, aggiornamento) dopo qualche secondo lo si lascia in primo piano."""
    if not IS_WINDOWS:
        return
    deadline = time.time() + duration
    minimized = 0
    while time.time() < deadline:
        time.sleep(0.4)
        pids = processes_in_folder(folder) if folder else set()
        hwnd, exe = _foreground_process()
        if pids:
            fg_pid = wintypes.DWORD()
            if hwnd:
                _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(fg_pid))
            if fg_pid.value not in pids:
                time.sleep(1.5)                 # lascia al gioco il tempo di aprire la sua finestra
                focus_game(pids)
            log.info("Gioco in primo piano, protezione avvio terminata")
            return
        if exe in LAUNCHER_EXES and minimized < max_minimize:
            _user32.ShowWindow(hwnd, SW_MINIMIZE)
            minimized += 1
            focus_gamedock(delay=0)
            log.info("Finestra di %s ridotta a icona durante l'avvio", exe)


# ------------------------------------------------- tasto Home del controller --

XINPUT_GUIDE = 0x0400
XINPUT_BACK = 0x0020          # tasto View
XINPUT_START = 0x0010         # tasto Menu
COMBO_HOLD = 0.8              # secondi per View + Menu


class HomeButtonWatcher(threading.Thread):
    """Legge i controller Xbox (XInput) anche quando il gioco è in primo piano.

    - Tasto Xbox (Guide): richiede di disattivare "Apri Xbox Game Bar con questo pulsante"
      nelle impostazioni di Windows, altrimenti Windows apre la Game Bar.
    - View + Menu tenuti premuti per 0,8 secondi: funziona sempre.
    I controller PlayStation funzionano solo se tradotti in XInput (es. Steam Input, DS4Windows).
    """

    def __init__(self, on_press):
        super().__init__(daemon=True, name="home-button")
        self.on_press = on_press
        self.last_fire = 0.0

    def _load(self):
        class XINPUT_GAMEPAD(ctypes.Structure):
            _fields_ = [("wButtons", wintypes.WORD), ("bLeftTrigger", ctypes.c_ubyte),
                        ("bRightTrigger", ctypes.c_ubyte), ("sThumbLX", ctypes.c_short),
                        ("sThumbLY", ctypes.c_short), ("sThumbRX", ctypes.c_short),
                        ("sThumbRY", ctypes.c_short)]

        class XINPUT_STATE(ctypes.Structure):
            # spazio extra: la versione "Ex" scrive un campo in più
            _fields_ = [("dwPacketNumber", wintypes.DWORD), ("Gamepad", XINPUT_GAMEPAD),
                        ("dwReserved", wintypes.DWORD)]

        self.state_type = XINPUT_STATE
        try:
            dll = ctypes.WinDLL("xinput1_4")
            func = dll[100]                 # XInputGetStateEx: include il tasto Guide
            self.guide_supported = True
        except (OSError, AttributeError):
            dll = ctypes.WinDLL("xinput9_1_0")
            func = dll.XInputGetState
            self.guide_supported = False
        func.argtypes = [wintypes.DWORD, ctypes.POINTER(XINPUT_STATE)]
        func.restype = wintypes.DWORD
        return func

    def _fire(self, reason):
        now = time.time()
        if now - self.last_fire < 1.5:
            return
        self.last_fire = now
        log.info("Tasto Home del controller (%s)", reason)
        try:
            self.on_press()
        except Exception:
            log.exception("Errore nel ritorno a GameDock")

    def run(self):
        if not IS_WINDOWS:
            return
        try:
            get_state = self._load()
        except OSError:
            log.warning("XInput non disponibile: tasto Home del controller disattivato")
            return
        state = self.state_type()
        prev_guide = False
        combo_since = None
        combo_done = False
        while True:
            buttons, connected = 0, False
            for index in range(4):
                if get_state(index, ctypes.byref(state)) == 0:
                    connected = True
                    buttons |= state.Gamepad.wButtons
            guide = bool(buttons & XINPUT_GUIDE)
            if guide and not prev_guide:
                self._fire("Xbox")
            prev_guide = guide

            if buttons & XINPUT_BACK and buttons & XINPUT_START:
                if combo_since is None:
                    combo_since = time.time()
                elif not combo_done and time.time() - combo_since >= COMBO_HOLD:
                    combo_done = True
                    self._fire("View + Menu")
            else:
                combo_since, combo_done = None, False
            time.sleep(0.05 if connected else 1.0)


# ---------------------------------------------------------------- volume del PC --

VK_VOLUME_MUTE, VK_VOLUME_DOWN, VK_VOLUME_UP = 0xAD, 0xAE, 0xAF


def volume(action, steps=2):
    """Simula i tasti multimediali del volume (ogni passo = 2%). Funziona con qualsiasi scheda audio."""
    if not IS_WINDOWS:
        return False
    key = {"up": VK_VOLUME_UP, "down": VK_VOLUME_DOWN, "mute": VK_VOLUME_MUTE}[action]
    for _ in range(1 if action == "mute" else steps):
        _user32.keybd_event(key, 0, 0, 0)
        _user32.keybd_event(key, 0, KEYEVENTF_KEYUP, 0)
    return True


# --------------------------------------------------------- risoluzione schermo --

if IS_WINDOWS:
    class DEVMODEW(ctypes.Structure):
        _fields_ = [
            ("dmDeviceName", wintypes.WCHAR * 32), ("dmSpecVersion", wintypes.WORD),
            ("dmDriverVersion", wintypes.WORD), ("dmSize", wintypes.WORD), ("dmDriverExtra", wintypes.WORD),
            ("dmFields", wintypes.DWORD), ("dmPositionX", wintypes.LONG), ("dmPositionY", wintypes.LONG),
            ("dmDisplayOrientation", wintypes.DWORD), ("dmDisplayFixedOutput", wintypes.DWORD),
            ("dmColor", ctypes.c_short), ("dmDuplex", ctypes.c_short), ("dmYResolution", ctypes.c_short),
            ("dmTTOption", ctypes.c_short), ("dmCollate", ctypes.c_short), ("dmFormName", wintypes.WCHAR * 32),
            ("dmLogPixels", wintypes.WORD), ("dmBitsPerPel", wintypes.DWORD), ("dmPelsWidth", wintypes.DWORD),
            ("dmPelsHeight", wintypes.DWORD), ("dmDisplayFlags", wintypes.DWORD),
            ("dmDisplayFrequency", wintypes.DWORD), ("dmICMMethod", wintypes.DWORD),
            ("dmICMIntent", wintypes.DWORD), ("dmMediaType", wintypes.DWORD), ("dmDitherType", wintypes.DWORD),
            ("dmReserved1", wintypes.DWORD), ("dmReserved2", wintypes.DWORD),
            ("dmPanningWidth", wintypes.DWORD), ("dmPanningHeight", wintypes.DWORD),
        ]

ENUM_CURRENT_SETTINGS = -1
DM_PELSWIDTH, DM_PELSHEIGHT, DM_DISPLAYFREQUENCY = 0x80000, 0x100000, 0x400000


def current_resolution():
    if not IS_WINDOWS:
        return None
    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if not _user32.EnumDisplaySettingsW(None, ENUM_CURRENT_SETTINGS, ctypes.byref(dm)):
        return None
    return {"width": dm.dmPelsWidth, "height": dm.dmPelsHeight, "fps": dm.dmDisplayFrequency}


def set_resolution(width, height, fps=None):
    """Cambia la risoluzione dello schermo principale (temporaneamente, non nel registro)."""
    if not IS_WINDOWS:
        return False
    dm = DEVMODEW()
    dm.dmSize = ctypes.sizeof(DEVMODEW)
    if not _user32.EnumDisplaySettingsW(None, ENUM_CURRENT_SETTINGS, ctypes.byref(dm)):
        return False
    dm.dmPelsWidth, dm.dmPelsHeight = int(width), int(height)
    dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT
    if fps:
        dm.dmDisplayFrequency = int(fps)
        dm.dmFields |= DM_DISPLAYFREQUENCY
    result = _user32.ChangeDisplaySettingsW(ctypes.byref(dm), 0)
    if result != 0 and fps:
        dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT          # frequenza non supportata: riprova senza
        result = _user32.ChangeDisplaySettingsW(ctypes.byref(dm), 0)
    log.info("Risoluzione %sx%s@%s: %s", width, height, fps, "ok" if result == 0 else f"errore {result}")
    return result == 0


def restore_resolution():
    """Torna alla risoluzione salvata nel registro (quella normale del PC)."""
    if not IS_WINDOWS:
        return False
    return _user32.ChangeDisplaySettingsW(None, 0) == 0
