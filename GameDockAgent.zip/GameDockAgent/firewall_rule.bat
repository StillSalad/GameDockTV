@echo off
rem Consente le connessioni in entrata sulla porta dell'Agent SOLO dalle reti private (casa).
rem Va eseguito come amministratore (tasto destro > Esegui come amministratore).
net session >nul 2>&1
if errorlevel 1 (
  echo Esegui questo file come amministratore: tasto destro ^> Esegui come amministratore.
  pause
  exit /b 1
)
netsh advfirewall firewall delete rule name="GameDock Agent" >nul 2>&1
netsh advfirewall firewall add rule name="GameDock Agent" dir=in action=allow protocol=TCP localport=8765 profile=private
echo.
echo Regola creata: porta 8765, solo reti private. Nessuna porta e' aperta verso Internet.
echo Controlla che la tua rete Wi-Fi sia impostata come "Privata" in Impostazioni ^> Rete e Internet.
pause
