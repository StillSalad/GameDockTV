"""
GameDock Agent - uso di CPU, RAM e GPU del PC (widget della Home).

Windows: GetSystemTimes / GlobalMemoryStatusEx (ctypes) e, se presente, nvidia-smi.
Linux: /proc (utile anche per i test e per il relay su Raspberry Pi).
Un thread in background campiona la CPU ogni 2 secondi: la richiesta risponde subito.
"""

import ctypes
import os
import shutil
import subprocess
import sys
import threading
import time

IS_WINDOWS = sys.platform.startswith("win")
_state = {"cpu": None, "gpu": None, "gpuName": None, "updated": 0}
_started = False


def _cpu_times():
    if IS_WINDOWS:
        from ctypes import wintypes
        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user))
        val = lambda ft: (ft.dwHighDateTime << 32) | ft.dwLowDateTime
        idle_t, total = val(idle), val(kernel) + val(user)     # il tempo kernel include già l'idle
        return idle_t, total
    with open("/proc/stat") as f:
        parts = [int(x) for x in f.readline().split()[1:]]
    idle_t = parts[3] + (parts[4] if len(parts) > 4 else 0)
    return idle_t, sum(parts)


def ram():
    if IS_WINDOWS:
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = MEMORYSTATUSEX()
        m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return None, None
        return int(m.dwMemoryLoad), round(m.ullTotalPhys / 2**30)
    info = {}
    with open("/proc/meminfo") as f:
        for line in f:
            k, v = line.split(":", 1)
            info[k] = int(v.split()[0])
    total, avail = info.get("MemTotal", 0), info.get("MemAvailable", 0)
    return (round(100 * (total - avail) / total) if total else None), round(total / 2**20)


def _gpu():
    """Uso della GPU NVIDIA tramite nvidia-smi (installato con i driver NVIDIA)."""
    exe = shutil.which("nvidia-smi")
    if not exe and IS_WINDOWS:
        candidate = os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe")
        exe = candidate if os.path.isfile(candidate) else None
    if not exe:
        return None, None
    try:
        flags = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0
        out = subprocess.run([exe, "--query-gpu=utilization.gpu,name", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=5, creationflags=flags).stdout.strip()
        usage, name = out.splitlines()[0].split(",", 1)
        return int(usage.strip()), name.strip()
    except (OSError, ValueError, IndexError, subprocess.SubprocessError):
        return None, None


def _sampler():
    prev = _cpu_times()
    tick = 0
    while True:
        time.sleep(2)
        try:
            cur = _cpu_times()
            d_idle, d_total = cur[0] - prev[0], cur[1] - prev[1]
            prev = cur
            if d_total > 0:
                _state["cpu"] = max(0, min(100, round(100 * (1 - d_idle / d_total))))
            if tick % 3 == 0:                    # la GPU ogni 6 secondi basta
                _state["gpu"], _state["gpuName"] = _gpu()
            _state["updated"] = time.time()
        except Exception:
            pass
        tick += 1


def start():
    global _started
    if not _started:
        _started = True
        threading.Thread(target=_sampler, daemon=True, name="sysinfo").start()


def snapshot():
    start()
    ram_pct, ram_total = ram()
    return {"cpu": _state["cpu"], "ram": ram_pct, "ramTotalGB": ram_total,
            "gpu": _state["gpu"], "gpuName": _state["gpuName"]}
