"""
GameDock Agent - avvio dei giochi e comandi di alimentazione.

Esegue SOLO azioni predefinite: aprire un URI di un launcher conosciuto,
avviare un eseguibile registrato nella libreria, spegnere/riavviare il PC.
Nessun comando arbitrario arriva mai dal browser.
"""

import logging
import os
import re
import shlex
import subprocess
import sys
import threading
import time

import console

log = logging.getLogger("gamedock.launcher")

ALLOWED_URI_PREFIXES = ("steam://", "com.epicgames.launcher://", "uplay://", "origin2://", "eadm://", "battlenet://")
XBOX_FAMILY_RE = re.compile(r"^[A-Za-z0-9.\-]+_[a-z0-9]+$")
XBOX_APP_RE = re.compile(r"^[A-Za-z0-9.\-]+$")
BATTLENET_CODE_RE = re.compile(r"^[A-Za-z0-9_]{1,12}$")
ALLOWED_EXTENSIONS = (".exe", ".lnk", ".url")
IS_WINDOWS = sys.platform.startswith("win")

_running = {}          # game_id -> {"proc": Popen | None, "pids": set, "start": ts}
_lock = threading.Lock()


class LaunchError(Exception):
    pass


def _windows_dir():
    return os.path.normcase(os.environ.get("WINDIR", r"C:\Windows"))


def validate_executable(path):
    """Controlla che un percorso sia un eseguibile ammesso. Ritorna il percorso normalizzato."""
    if not path or not isinstance(path, str):
        raise LaunchError("Percorso dell'eseguibile mancante.")
    path = os.path.normpath(path.strip().strip('"'))
    if not path.lower().endswith(ALLOWED_EXTENSIONS):
        raise LaunchError("Sono ammessi solo file .exe, .lnk o .url.")
    if not os.path.isfile(path):
        raise LaunchError(f"File non trovato: {path}")
    if IS_WINDOWS and os.path.normcase(path).startswith(_windows_dir()):
        raise LaunchError("Gli eseguibili di sistema di Windows non possono essere aggiunti.")
    return path


def _split_args(args):
    if not args:
        return []
    parts = shlex.split(args, posix=False)
    return [p[1:-1] if len(p) >= 2 and p[0] == p[-1] == '"' else p for p in parts]


def _open_uri(uri):
    if not uri.startswith(ALLOWED_URI_PREFIXES):
        raise LaunchError("Tipo di avvio non supportato.")
    if IS_WINDOWS:
        os.startfile(uri)  # noqa: S606 - URI di un launcher conosciuto
    else:
        subprocess.Popen(["xdg-open", uri])


def _watch_folder(game_id, folder, on_exit):
    """Per i giochi avviati da un launcher: attende che parta un processo nella cartella
    del gioco, poi aspetta che si chiudano tutti per misurare la sessione."""
    deadline = time.time() + 180
    pids = set()
    while time.time() < deadline and not pids:
        time.sleep(3)
        pids = console.processes_in_folder(folder)
    if not pids:
        log.info("Nessun processo rilevato per %s (sessione non misurata)", game_id)
        return
    start = time.time()
    with _lock:
        _running[game_id] = {"proc": None, "pids": pids, "start": start}
    misses = 0
    while misses < 2:            # due controlli a vuoto di fila = gioco chiuso
        time.sleep(3)
        pids = console.processes_in_folder(folder)
        if pids:
            misses = 0
            with _lock:
                if game_id in _running:
                    _running[game_id]["pids"] = pids
        else:
            misses += 1
    seconds = int(time.time() - start)
    with _lock:
        _running.pop(game_id, None)
    log.info("Sessione terminata: %s (%ss)", game_id, seconds)
    on_exit(game_id, seconds)


def _watch(game_id, proc, start, on_exit):
    proc.wait()
    seconds = int(time.time() - start)
    with _lock:
        _running.pop(game_id, None)
    log.info("Sessione terminata: %s (%ss)", game_id, seconds)
    on_exit(game_id, seconds)


def launch(game, on_exit, guard=False):
    """Avvia un gioco. on_exit(game_id, seconds) viene chiamato quando la sessione termina.
    guard=True (modalità console): impedisce ai launcher di coprire GameDock durante l'avvio."""
    launch_info = game.get("launch") or {}
    game_id = game["id"]
    folder = game.get("path")
    if guard and console.IS_WINDOWS and console.safe_watch_folder(folder):
        threading.Thread(target=console.guard_launch, args=(folder,), daemon=True).start()

    if launch_info.get("type") in ("battlenet", "shell"):
        kind = launch_info["type"]
        if kind == "battlenet":
            code = str(launch_info.get("code", ""))
            exe = launch_info.get("exe")
            if not BATTLENET_CODE_RE.match(code):
                raise LaunchError("Codice Battle.net non valido.")
            if IS_WINDOWS and exe and os.path.isfile(exe):
                subprocess.Popen([exe, f"--exec=launch {code}"], cwd=os.path.dirname(exe),
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                _open_uri(f"battlenet://{code}")
        else:
            family, app = str(launch_info.get("family", "")), str(launch_info.get("app", ""))
            if not (XBOX_FAMILY_RE.match(family) and XBOX_APP_RE.match(app)):
                raise LaunchError("Gioco Xbox non valido.")
            if not IS_WINDOWS:
                raise LaunchError("I giochi Xbox si avviano solo su Windows.")
            subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{family}!{app}"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log.info("Avviato via %s: %s", "Battle.net" if kind == "battlenet" else "app Xbox", game_id)
        if console.IS_WINDOWS and console.safe_watch_folder(folder):
            threading.Thread(target=_watch_folder, args=(game_id, folder, on_exit), daemon=True).start()
            return {"tracked": True, "watching": True}
        return {"tracked": False}

    if launch_info.get("type") == "steam":
        exe = launch_info.get("exe")
        appid = str(launch_info.get("appid", ""))
        if IS_WINDOWS and exe and os.path.isfile(exe) and appid.isdigit():
            # Se Steam è già aperto, steam.exe passa il comando all'istanza esistente
            subprocess.Popen([exe, "-silent", "-applaunch", appid], cwd=os.path.dirname(exe),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            _open_uri(launch_info["uri"])
        log.info("Avviato via Steam: %s", game_id)
        if console.IS_WINDOWS and console.safe_watch_folder(folder):
            threading.Thread(target=_watch_folder, args=(game_id, folder, on_exit), daemon=True).start()
            return {"tracked": True, "watching": True}
        return {"tracked": False}

    if launch_info.get("type") == "uri":
        _open_uri(launch_info["uri"])
        log.info("Avviato via launcher: %s", game_id)
        folder = game.get("path")
        if console.IS_WINDOWS and console.safe_watch_folder(folder):
            threading.Thread(target=_watch_folder, args=(game_id, folder, on_exit), daemon=True).start()
            return {"tracked": True, "watching": True}
        return {"tracked": False}

    path = validate_executable(launch_info.get("path") or game.get("executable"))
    if not path.lower().endswith(".exe"):
        if IS_WINDOWS:
            os.startfile(path)  # noqa: S606 - collegamento registrato dall'utente
        else:
            raise LaunchError("I collegamenti .lnk/.url funzionano solo su Windows.")
        return {"tracked": False}

    with _lock:
        info = _running.get(game_id)
        if info and info["proc"] is not None and info["proc"].poll() is None:
            return {"tracked": True, "alreadyRunning": True}

    flags = 0
    if IS_WINDOWS:
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    proc = subprocess.Popen([path] + _split_args(launch_info.get("args", "")),
                            cwd=os.path.dirname(path), creationflags=flags,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    start = time.time()
    with _lock:
        _running[game_id] = {"proc": proc, "pids": {proc.pid}, "start": start}
    threading.Thread(target=_watch, args=(game_id, proc, start, on_exit), daemon=True).start()
    log.info("Avviato eseguibile: %s (pid %s)", game_id, proc.pid)
    return {"tracked": True}


def close(game_id):
    with _lock:
        info = _running.get(game_id)
    if not info:
        raise LaunchError("Questo gioco non è stato avviato da GameDock o è già chiuso.")
    if info["proc"] is not None:
        if info["proc"].poll() is not None:
            raise LaunchError("Il gioco è già chiuso.")
        info["proc"].terminate()
        return True
    for pid in info["pids"]:
        subprocess.run(["taskkill", "/PID", str(pid), "/T"], check=False,
                       creationflags=subprocess.CREATE_NO_WINDOW,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True


def focus(game):
    """Riporta in primo piano la finestra del gioco (se avviato da GameDock)."""
    with _lock:
        info = _running.get(game["id"])
        pids = set(info["pids"]) if info else set()
    if not info:
        raise LaunchError("Il gioco non è in esecuzione.")
    if info["proc"] is not None:
        folder = os.path.dirname((game.get("launch") or {}).get("path") or game.get("executable") or "")
        if console.safe_watch_folder(folder):
            pids |= console.processes_in_folder(folder)   # anche i processi figli (es. launcher -> gioco)
    if not console.focus_game(pids):
        raise LaunchError("Finestra del gioco non trovata.")
    return True


def running_ids():
    with _lock:
        return [gid for gid, info in _running.items()
                if info["proc"] is None or info["proc"].poll() is None]


def power(action):
    """action: shutdown | restart | cancel. Ritardo di 10 secondi per permettere l'annullamento."""
    commands = {
        "shutdown": ["shutdown", "/s", "/t", "10"],
        "restart": ["shutdown", "/r", "/t", "10"],
        "cancel": ["shutdown", "/a"],
    }
    if action not in commands:
        raise LaunchError("Azione non valida.")
    if not IS_WINDOWS:
        raise LaunchError("Spegnimento disponibile solo su Windows.")
    subprocess.run(commands[action], check=False, creationflags=subprocess.CREATE_NO_WINDOW)
    log.info("Comando alimentazione: %s", action)
