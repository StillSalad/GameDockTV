; =============================================================================
;  GameDock Setup - installer per Windows (Inno Setup 6, gratuito: jrsoftware.org)
;  Crea:  Output\GameDock-Setup-<versione>.exe
;  Prima: GameDockAgent.exe con PyInstaller (vedi build_installer.bat)
; =============================================================================

#define AppName "GameDock"
#define AppVersion "1.0.0"
#define AppPublisher "LolloMarta"
#define AppExe "GameDockAgent.exe"

[Setup]
AppId={{B5E3C1D2-6F7A-4E8B-9C0D-1A2B3C4D5E6F}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
; Installazione per l'utente: niente permessi di amministratore e cartella scrivibile
; (l'Agent salva lì configurazione, libreria e copertine)
DefaultDirName={localappdata}\Programs\GameDock
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\Output
OutputBaseFilename=GameDock-Setup-{#AppVersion}
SetupIconFile=..\gamedock.ico
UninstallDisplayIcon={app}\gamedock.ico
UninstallDisplayName={#AppName}
WizardStyle=modern
WizardImageFile=wizard.bmp
WizardSmallImageFile=wizard-small.bmp
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=force

[Languages]
Name: "italian"; MessagesFile: "compiler:Languages\Italian.isl"

[Messages]
italian.WelcomeLabel2=Questo programma installerà [name/ver] sul computer.%n%nGameDock trasforma il PC nella console della tua TV: libreria dei giochi, avvio con il controller e streaming con Moonlight.

[Tasks]
Name: "desktopicon"; Description: "Crea l'icona GameDock sul desktop"; GroupDescription: "Icone:"
Name: "agentstartup"; Description: "Avvia GameDock Agent con Windows, in background (consigliato: serve alla TV)"; GroupDescription: "Avvio automatico:"
Name: "consolestartup"; Description: "Apri GameDock a schermo intero all'avvio di Windows (modalità console)"; GroupDescription: "Avvio automatico:"; Flags: unchecked
Name: "firewall"; Description: "Consenti l'accesso dalla rete di casa (TV, iPad). Chiede i permessi di amministratore"; GroupDescription: "Rete:"

[Dirs]
Name: "{app}\games\covers"
Name: "{app}\apk"
Name: "{app}\branding"

[Files]
Source: "..\dist\GameDockAgent\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\web\*"; DestDir: "{app}\web"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\branding\*"; DestDir: "{app}\branding"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\apk\*"; DestDir: "{app}\apk"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "..\gamedock.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\LEGGIMI.txt"; DestDir: "{app}"; Flags: ignoreversion
; La configurazione esistente (codice di accesso, Sunshine...) non viene mai sovrascritta
Source: "..\config.json"; DestDir: "{app}"; Flags: onlyifdoesntexist uninsneveruninstall

[Icons]
Name: "{autoprograms}\GameDock"; Filename: "{app}\{#AppExe}"; Parameters: "--open-console"; IconFilename: "{app}\gamedock.ico"; Comment: "Il tuo gaming, direttamente sulla TV"
Name: "{autoprograms}\Disinstalla GameDock"; Filename: "{uninstallexe}"
Name: "{autodesktop}\GameDock"; Filename: "{app}\{#AppExe}"; Parameters: "--open-console"; IconFilename: "{app}\gamedock.ico"; Tasks: desktopicon
Name: "{userstartup}\GameDock Agent"; Filename: "{app}\{#AppExe}"; IconFilename: "{app}\gamedock.ico"; Tasks: agentstartup
Name: "{userstartup}\GameDock"; Filename: "{app}\{#AppExe}"; Parameters: "--open-console"; IconFilename: "{app}\gamedock.ico"; Tasks: consolestartup

[Run]
; Regola firewall solo per le reti private (casa), legata al programma: nessuna porta aperta verso Internet
Filename: "{cmd}"; Parameters: "/c netsh advfirewall firewall delete rule name=""GameDock Agent"" & netsh advfirewall firewall add rule name=""GameDock Agent"" dir=in action=allow program=""{app}\{#AppExe}"" profile=private"; Verb: "runas"; Flags: runhidden shellexec waituntilterminated; Tasks: firewall; StatusMsg: "Configurazione del firewall…"
Filename: "{app}\{#AppExe}"; Parameters: "--open-console"; Description: "Apri GameDock adesso"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\taskkill.exe"; Parameters: "/IM {#AppExe} /F"; Flags: runhidden; RunOnceId: "StopAgent"

[UninstallDelete]
Type: files; Name: "{app}\agent.log*"

[Code]
// Chiude l'Agent se è in esecuzione, così i file possono essere aggiornati
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/IM {#AppExe} /F', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  Result := True;
end;
