@echo off
rem ==========================================================================
rem  GameDock Console - apre GameDock sul PC a schermo intero (modalita' kiosk)
rem  Avvia anche l'Agent in background se non e' gia' in esecuzione.
rem  Per uscire: Alt + F4
rem ==========================================================================
cd /d "%~dp0"
set "URL=http://localhost:8765/?console=1"
set "HEALTH=try{$null=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://localhost:8765/api/health; exit 0}catch{exit 1}"

powershell -NoProfile -Command "%HEALTH%" >nul 2>&1
if not errorlevel 1 goto ready

echo Avvio di GameDock Agent...
where pyw >nul 2>&1
if %errorlevel%==0 (
  start "" pyw -3 "%~dp0agent.py"
) else (
  start "" pythonw "%~dp0agent.py"
)
for /l %%i in (1,1,20) do (
  timeout /t 1 /nobreak >nul
  powershell -NoProfile -Command "%HEALTH%" >nul 2>&1 && goto ready
)
echo GameDock Agent non risponde. Controlla agent.log nella cartella dell'Agent.
pause
exit /b 1

:ready
rem Profilo browser dedicato: non interferisce con il tuo Chrome/Edge di tutti i giorni
set "PROFILE=%LOCALAPPDATA%\GameDock\browser"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%CHROME%" (
  start "" "%CHROME%" --kiosk --app="%URL%" --user-data-dir="%PROFILE%\chrome" --no-first-run --no-default-browser-check --disable-translate --disable-features=Translate
  exit /b 0
)
if exist "%EDGE%" (
  start "" "%EDGE%" --kiosk "%URL%" --edge-kiosk-type=fullscreen --user-data-dir="%PROFILE%\edge" --no-first-run
  exit /b 0
)
echo Non ho trovato ne' Google Chrome ne' Microsoft Edge.
echo Apri manualmente %URL% e premi F11.
pause
