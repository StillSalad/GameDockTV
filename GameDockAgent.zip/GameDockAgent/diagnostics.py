"""
GameDock Agent - test di diagnostica. Ogni test ritorna PASS, WARNING o ERROR.
"""

import os
import subprocess
import sys

import network
import scanner

IS_WINDOWS = sys.platform.startswith("win")


def _process_running(exe_name):
    if not IS_WINDOWS:
        return False
    try:
        out = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {exe_name}", "/NH"],
                             capture_output=True, text=True, errors="ignore",
                             creationflags=subprocess.CREATE_NO_WINDOW).stdout
        return exe_name.lower() in out.lower()
    except OSError:
        return False


def _test(test_id, label, status, detail):
    return {"id": test_id, "label": label, "status": status, "detail": detail}


def run(cfg):
    tests = [_test("agent", "GameDock Agent", "PASS", "L'Agent risponde.")]

    adapter = network.adapter_info()
    if adapter["connection"] == "wifi":
        tests.append(_test("wol", "Wake-on-LAN", "WARNING",
                           "Il PC è collegato in Wi-Fi: quasi nessuna scheda Wi-Fi si riaccende "
                           "con Wake-on-LAN. Usa un cavo Ethernet o il 'Wake PC' di Moonlight."))
    elif adapter["connection"] == "ethernet":
        tests.append(_test("wol", "Wake-on-LAN", "PASS",
                           f"Connessione via cavo. MAC {adapter['mac']}. Abilita WoL nel BIOS "
                           "e nelle proprietà della scheda di rete."))
    else:
        tests.append(_test("wol", "Wake-on-LAN", "WARNING", "Tipo di connessione non rilevato."))

    scanner.scan_all(cfg["scan"])
    counts = scanner.last_counts()
    labels = {"steam": "Steam", "ea": "EA App", "epic": "Epic Games", "ubisoft": "Ubisoft Connect",
              "gog": "GOG Galaxy", "battlenet": "Battle.net", "xbox": "App Xbox / Game Pass",
              "rockstar": "Rockstar Games Launcher"}
    for key, label in labels.items():
        count = counts.get(key)
        if count is None:
            tests.append(_test(key, label, "WARNING", "Rilevamento disattivato in config.json."))
        elif count > 0:
            tests.append(_test(key, label, "PASS", f"{count} giochi trovati."))
        else:
            tests.append(_test(key, label, "WARNING",
                               "Nessun gioco trovato. Se lo usi, aggiungi i giochi a mano."))

    sunshine = cfg["streaming"].get("sunshinePath", "")
    if _process_running("sunshine.exe"):
        tests.append(_test("streaming", "Sunshine", "PASS", "Sunshine è in esecuzione."))
    elif sunshine and os.path.isfile(sunshine):
        tests.append(_test("streaming", "Sunshine", "WARNING",
                           "Sunshine è installato ma non in esecuzione. Avvialo o attiva il servizio."))
    else:
        tests.append(_test("streaming", "Sunshine", "ERROR",
                           "Sunshine non trovato. Installalo da github.com/LizardByte/Sunshine."))

    sc = cfg.get("sunshine", {})
    if sc.get("username") and sc.get("password"):
        import sunshine
        try:
            info = sunshine.test(sc)
            tests.append(_test("sunshine-api", "Collegamento a Sunshine", "PASS",
                               f"Collegato: {info['apps']} app in Sunshine."))
        except sunshine.SunshineError as e:
            tests.append(_test("sunshine-api", "Collegamento a Sunshine", "ERROR", str(e)))
    else:
        tests.append(_test("sunshine-api", "Collegamento a Sunshine", "WARNING",
                           "Credenziali non inserite: Impostazioni > Streaming > Sunshine."))

    tests.append(_test("power", "Spegnimento remoto",
                       "PASS" if cfg.get("allowPower") else "WARNING",
                       "Consentito." if cfg.get("allowPower") else "Disattivato in config.json."))
    return {"tests": tests, "adapter": adapter}
