@echo off
rem Crea l'icona GameDock sul desktop e nel menu Start.
rem Doppio clic sull'icona: avvia l'Agent (se serve) e apre il launcher a schermo intero.
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (py -3 agent.py --shortcuts desktop,startMenu) else (python agent.py --shortcuts desktop,startMenu)
echo.
echo Fatto: trovi l'icona GameDock sul desktop e nel menu Start.
pause
