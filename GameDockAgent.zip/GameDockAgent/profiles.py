"""
GameDock Agent - profili e statistiche.

Ogni profilo ha nome, avatar, tema e i suoi preferiti. Lo storico delle sessioni
(library["history"]) registra chi ha giocato a cosa e per quanto: da lì vengono
"Recenti", tempo di gioco per profilo, statistiche e traguardi.
"""

import re
import time
import uuid

import storage

MAX_HISTORY = 5000
MAX_PROFILES = 8
THEMES = ("default", "light", "midnight", "neon", "minimal")


class ProfileError(Exception):
    pass


def list_profiles():
    return [public(p) for p in storage.load_library().get("profiles", [])]


def public(p):
    return {"id": p["id"], "name": p["name"], "avatar": p.get("avatar", "a01"), "theme": p.get("theme", "default")}


def get(profile_id):
    if not profile_id:
        return None
    return next((p for p in storage.load_library().get("profiles", []) if p["id"] == profile_id), None)


def _clean(body, current=None):
    data = dict(current or {})
    if "name" in body:
        name = re.sub(r"\s+", " ", str(body["name"])).strip()[:20]
        if not name:
            raise ProfileError("Il nome del profilo non può essere vuoto.")
        data["name"] = name
    if "avatar" in body and re.fullmatch(r"a\d{2}", str(body["avatar"])):
        data["avatar"] = body["avatar"]
    if body.get("theme") in THEMES:
        data["theme"] = body["theme"]
    return data


def create(body):
    data = _clean(body)
    if "name" not in data:
        raise ProfileError("Inserisci il nome del profilo.")

    def mutate(lib):
        profiles = lib.setdefault("profiles", [])
        if len(profiles) >= MAX_PROFILES:
            raise ProfileError(f"Puoi creare al massimo {MAX_PROFILES} profili.")
        profile = {"id": uuid.uuid4().hex[:10], "avatar": "a01", "theme": "default", "favorites": [], **data}
        profiles.append(profile)
        return public(profile)
    return storage.update_library(mutate)


def update(profile_id, body):
    def mutate(lib):
        for i, p in enumerate(lib.get("profiles", [])):
            if p["id"] == profile_id:
                lib["profiles"][i] = _clean(body, p)
                return public(lib["profiles"][i])
        raise ProfileError("Profilo non trovato.")
    return storage.update_library(mutate)


def delete(profile_id):
    def mutate(lib):
        before = len(lib.get("profiles", []))
        lib["profiles"] = [p for p in lib.get("profiles", []) if p["id"] != profile_id]
        if len(lib["profiles"]) == before:
            raise ProfileError("Profilo non trovato.")
        lib["history"] = [h for h in lib.get("history", []) if h.get("p") != profile_id]
    storage.update_library(mutate)


def set_favorite(profile_id, game_id, favorite):
    def mutate(lib):
        for p in lib.get("profiles", []):
            if p["id"] == profile_id:
                favs = [f for f in p.get("favorites", []) if f != game_id]
                if favorite:
                    favs.append(game_id)
                p["favorites"] = favs
                return
        raise ProfileError("Profilo non trovato.")
    storage.update_library(mutate)


# ------------------------------------------------------------------ storico --

def history_start(lib, game_id, profile_id):
    """Da chiamare dentro update_library: registra l'inizio di una sessione."""
    hist = lib.setdefault("history", [])
    hist.append({"p": profile_id or "", "g": game_id, "t": int(time.time()), "s": 0})
    if len(hist) > MAX_HISTORY:
        del hist[: len(hist) - MAX_HISTORY]


def history_end(lib, game_id, seconds):
    """Da chiamare dentro update_library: chiude l'ultima sessione aperta di quel gioco."""
    for entry in reversed(lib.get("history", [])):
        if entry["g"] == game_id and entry["s"] == 0:
            entry["s"] = max(0, int(seconds))
            return


def per_game(history, profile_id):
    """{game_id: {"last": ts, "seconds": n, "sessions": n}} per un profilo."""
    out = {}
    for h in history:
        if profile_id is not None and h.get("p") != profile_id:
            continue
        g = out.setdefault(h["g"], {"last": 0, "seconds": 0, "sessions": 0})
        g["last"] = max(g["last"], h["t"])
        g["seconds"] += h.get("s", 0)
        g["sessions"] += 1
    return out


# --------------------------------------------------------------- statistiche --

def _day(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def stats(profile_id, games):
    """Statistiche per un profilo (o per tutti, se profile_id è None).
    games: elenco giochi pubblici (id, name, platform, cover) per arricchire i dati."""
    lib = storage.load_library()
    history = [h for h in lib.get("history", []) if profile_id is None or h.get("p") == profile_id]
    info = {g["id"]: g for g in games}
    now = time.time()
    today = _day(now)

    aggregated = per_game(history, None)
    # dati precedenti ai profili (solo per la vista "tutti")
    if profile_id is None:
        for gid, sess in lib.get("sessions", {}).items():
            if gid not in aggregated and sess.get("playtime"):
                aggregated[gid] = {"last": sess.get("lastPlayed", 0), "seconds": sess["playtime"],
                                   "sessions": sess.get("count", 1)}

    top = []
    for gid, a in aggregated.items():
        g = info.get(gid)
        if not g:
            continue
        top.append({"id": gid, "name": g["name"], "platform": g["platform"], "cover": g.get("cover"),
                    "seconds": a["seconds"], "sessions": a["sessions"], "last": a["last"]})
    top.sort(key=lambda x: (x["seconds"], x["sessions"]), reverse=True)

    daily = {}
    for i in range(29, -1, -1):
        daily[_day(now - i * 86400)] = 0
    days_played = set()
    night = 0
    for h in history:
        d = _day(h["t"])
        days_played.add(d)
        if d in daily:
            daily[d] += h.get("s", 0)
        if time.localtime(h["t"]).tm_hour < 5:
            night += 1

    # serie di giorni consecutivi (attuale e migliore)
    ordered = sorted(days_played)
    best = run = 0
    prev = None
    for d in ordered:
        t = time.mktime(time.strptime(d, "%Y-%m-%d"))
        run = run + 1 if prev is not None and round((t - prev) / 86400) == 1 else 1
        best = max(best, run)
        prev = t
    streak = 0
    cursor = now
    if _day(cursor) not in days_played:
        cursor -= 86400                      # la serie resta valida se hai giocato ieri
    while _day(cursor) in days_played:
        streak += 1
        cursor -= 86400

    month = time.strftime("%Y-%m", time.localtime(now))
    month_hist = [h for h in history if _day(h["t"]).startswith(month)]
    month_games = per_game(month_hist, None)
    month_top = max(month_games.items(), key=lambda kv: kv[1]["seconds"], default=(None, None))[0]

    return {
        "totalSeconds": sum(a["seconds"] for a in aggregated.values()),
        "sessions": sum(a["sessions"] for a in aggregated.values()),
        "gamesPlayed": len([g for g in top if g["sessions"]]),
        "libraryCount": len(games),
        "platforms": sorted({g["platform"] for g in top}),
        "top": top[:10],
        "daily": [{"day": d, "seconds": s} for d, s in daily.items()],
        "streak": streak,
        "bestStreak": best,
        "daysPlayed": len(days_played),
        "nightSessions": night,
        "today": today,
        "month": {
            "seconds": sum(a["seconds"] for a in month_games.values()),
            "days": len({_day(h["t"]) for h in month_hist}),
            "sessions": len(month_hist),
            "topGame": info.get(month_top, {}).get("name") if month_top else None,
        },
    }
