"""
GameDock Agent - app GameDock TV: versione e download dell'APK.

L'APK aggiornato va copiato in GameDockAgent/apk/. L'Agent legge versionCode e
versionName direttamente dal file (AndroidManifest.xml in formato XML binario di
Android), quindi non serve scrivere a mano nessun numero di versione.
"""

import glob
import logging
import os
import struct
import zipfile

import storage

log = logging.getLogger("gamedock.apk")
APK_DIR = os.path.join(storage.BASE_DIR, "apk")
PACKAGE = "com.lollomarta.gamedock"

# Tipi di chunk del formato AXML
RES_STRING_POOL = 0x0001
RES_XML = 0x0003
RES_XML_START_ELEMENT = 0x0102
RES_XML_RESOURCE_MAP = 0x0180
ATTR_VERSION_CODE = 0x0101021B      # android:versionCode
ATTR_VERSION_NAME = 0x0101021C      # android:versionName
TYPE_STRING = 0x03
UTF8_FLAG = 0x100

_cache = {}


def _string_pool(data, start):
    _, header_size, _, count, _, flags, strings_start, _ = struct.unpack_from("<HHIIIIII", data, start)
    utf8 = bool(flags & UTF8_FLAG)
    offsets = struct.unpack_from(f"<{count}I", data, start + header_size)
    base = start + strings_start
    strings = []
    for off in offsets:
        pos = base + off
        if utf8:
            # lunghezza UTF-16 (1-2 byte), poi lunghezza in byte UTF-8 (1-2 byte)
            n = data[pos]
            pos += 2 if n & 0x80 else 1
            size = data[pos]
            if size & 0x80:
                size = ((size & 0x7F) << 8) | data[pos + 1]
                pos += 2
            else:
                pos += 1
            strings.append(data[pos:pos + size].decode("utf-8", "replace"))
        else:
            size = struct.unpack_from("<H", data, pos)[0]
            pos += 2
            if size & 0x8000:
                size = ((size & 0x7FFF) << 16) | struct.unpack_from("<H", data, pos)[0]
                pos += 2
            strings.append(data[pos:pos + size * 2].decode("utf-16-le", "replace"))
    return strings


def read_manifest(apk_path):
    """Ritorna {"package", "versionCode", "versionName"} leggendo l'APK."""
    with zipfile.ZipFile(apk_path) as z:
        data = z.read("AndroidManifest.xml")
    if struct.unpack_from("<H", data, 0)[0] != RES_XML:
        raise ValueError("AndroidManifest.xml non valido")
    pos = struct.unpack_from("<H", data, 2)[0]
    strings, res_ids = [], []
    while pos + 8 <= len(data):
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", data, pos)
        if chunk_size <= 0:
            break
        if chunk_type == RES_STRING_POOL:
            strings = _string_pool(data, pos)
        elif chunk_type == RES_XML_RESOURCE_MAP:
            n = (chunk_size - header_size) // 4
            res_ids = list(struct.unpack_from(f"<{n}I", data, pos + header_size))
        elif chunk_type == RES_XML_START_ELEMENT:
            _, name_idx, attr_start, attr_size, attr_count = struct.unpack_from("<IIHHH", data, pos + 16)
            if strings[name_idx] == "manifest":
                info = {}
                base = pos + 16 + attr_start
                for i in range(attr_count):
                    _, a_name, a_raw, _, _, a_type, a_data = struct.unpack_from("<IIIHBBI", data, base + i * attr_size)
                    res_id = res_ids[a_name] if a_name < len(res_ids) else None
                    name = strings[a_name] if a_name < len(strings) else ""
                    if res_id == ATTR_VERSION_CODE or name == "versionCode":
                        info["versionCode"] = a_data
                    elif res_id == ATTR_VERSION_NAME or name == "versionName":
                        idx = a_raw if a_raw != 0xFFFFFFFF else (a_data if a_type == TYPE_STRING else None)
                        info["versionName"] = strings[idx] if idx is not None else str(a_data)
                    elif name == "package":
                        info["package"] = strings[a_raw] if a_raw != 0xFFFFFFFF else ""
                return info
        pos += chunk_size
    raise ValueError("Elemento <manifest> non trovato")


def latest():
    """L'APK di GameDock TV con la versione più alta nella cartella apk/, oppure None."""
    best = None
    for path in glob.glob(os.path.join(APK_DIR, "*.apk")):
        try:
            mtime = os.path.getmtime(path)
            cached = _cache.get(path)
            if not cached or cached[0] != mtime:
                cached = (mtime, read_manifest(path))
                _cache[path] = cached
            info = cached[1]
        except (OSError, ValueError, KeyError, zipfile.BadZipFile, struct.error, IndexError) as e:
            log.warning("APK non leggibile (%s): %s", os.path.basename(path), e)
            continue
        if info.get("package") and info["package"] != PACKAGE:
            continue            # un altro APK finito nella cartella per sbaglio
        if not best or info.get("versionCode", 0) > best["versionCode"]:
            best = {"path": path, "versionCode": info.get("versionCode", 0),
                    "versionName": info.get("versionName", ""), "size": os.path.getsize(path)}
    return best
