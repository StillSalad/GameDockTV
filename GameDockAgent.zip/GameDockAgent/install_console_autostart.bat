@echo off
rem Apre GameDock (e avvia l'Agent) automaticamente a ogni accesso a Windows.
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (py -3 agent.py --shortcuts autostart) else (python agent.py --shortcuts autostart)
echo.
echo Fatto: a ogni accesso a Windows si aprira' GameDock a schermo intero.
echo Per disattivarlo: uninstall_console_autostart.bat
pause
