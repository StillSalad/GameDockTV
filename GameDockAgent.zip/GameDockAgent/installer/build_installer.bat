@echo off
rem ===========================================================================
rem  Crea GameDock-Setup.exe sul tuo PC.
rem  Serve: Python 3 (python.org) e Inno Setup 6 (gratuito: jrsoftware.org/isdl.php)
rem ===========================================================================
cd /d "%~dp0\.."

echo [1/3] Installo PyInstaller...
py -3 -m pip install --upgrade pyinstaller || goto :errore

echo [2/3] Creo GameDockAgent.exe...
py -3 -m PyInstaller --noconfirm --clean --onedir --noconsole --name GameDockAgent --icon gamedock.ico agent.py || goto :errore

echo [3/3] Creo l'installer...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup 6 non trovato. Scaricalo da https://jrsoftware.org/isdl.php e riprova.
  pause
  exit /b 1
)
"%ISCC%" installer\GameDock.iss || goto :errore

echo.
echo Fatto! Trovi l'installer nella cartella Output.
explorer Output
pause
exit /b 0

:errore
echo.
echo Qualcosa e' andato storto: leggi il messaggio qui sopra.
pause
exit /b 1
