@echo off
rem Per creare l'installer completo usa installer\build_installer.bat
call "%~dp0installer\build_installer.bat"
