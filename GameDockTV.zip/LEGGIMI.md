# GameDock TV - app Android TV

App per Xiaomi TV Stick, Android TV, Google TV (e anche telefoni/tablet Android).
Apre GameDock dal PC a schermo intero e aggiunge:

- **ricerca automatica del PC** al primo avvio (nessun indirizzo da scrivere, di solito);
- **PC spento?** schermata con **Accendi PC** (Wake-on-LAN inviato dalla TV stessa, serve il PC collegato via cavo);
- **Apri Moonlight** affidabile (se Moonlight non è installato apre il Play Store);
- icona e banner GameDock nella schermata principale della TV.

## 1A. Creare l'APK con GitHub (senza installare niente) - consigliato

GitHub costruisce l'APK al posto tuo, gratis. Non serve caricare cartelle: bastano un file zip e un file di testo.

1. Vai su **github.com** e crea un account gratuito.
2. **+ › New repository** › nome `GameDockTV` › **Private** › **Create repository**.
3. Clicca **"creating a new file"** (o **Add file › Create new file**).
   - Come nome scrivi esattamente: `.github/workflows/build-apk.yml` (le `/` creano le cartelle da sole).
   - Nel riquadro grande incolla tutto il contenuto del file `build-apk.yml` (lo trovi in `.github/workflows/` dentro questa cartella).
   - Premi **Commit changes**.
4. **Add file › Upload files** › scegli il file **`GameDockTV.zip`** › **Commit changes**.
   (Un solo file: funziona anche da telefono o iPad.)
5. Scheda **Actions**: "Crea APK GameDock TV" è in esecuzione. Dopo 5-10 minuti il pallino diventa verde.
6. Clicca l'esecuzione verde › in fondo, **Artifacts** › **GameDock-APK**: dentro c'è `GameDock-1.1.apk`.

Per una nuova versione: ricarica `GameDockTV.zip` aggiornato (con `versionCode` più alto) con **Add file › Upload files**. GitHub ricostruisce l'APK da solo.

## 1B. Creare l'APK con Android Studio

1. Installa **Android Studio** da https://developer.android.com/studio (gratuito).
2. Avvialo e completa la configurazione iniziale ("Standard"): scarica l'SDK Android.
3. **File › Open** e scegli la cartella **`GameDockTV`** (quella che contiene `settings.gradle`).
4. Aspetta la fine di **Gradle sync** (barra in basso). La prima volta scarica diversi componenti: può volerci qualche minuto.
   - Se compare "Android SDK Platform 34 missing" (o simile), clicca il link per installarlo.
   - Se propone di aggiornare il "Android Gradle Plugin", puoi accettare o rifiutare: funziona in entrambi i casi.
5. Menu **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
6. Al termine clicca **locate** nell'avviso in basso a destra: il file è
   `GameDockTV/app/build/outputs/apk/debug/app-debug.apk`.

Rinominalo pure in `GameDock.apk`.

## 2. Installarlo sulla Xiaomi TV Stick

1. Sulla TV: **Impostazioni › Privacy › Sicurezza e limitazioni › Origini sconosciute** e consenti l'app che userai per installare (es. "Send Files to TV" o "Downloader").
   (Su alcune versioni: Impostazioni › App › Sicurezza e limitazioni.)
2. Installa **Send Files to TV** sia sulla TV (Play Store) sia sul telefono o PC, e invia `GameDock.apk` alla TV.
3. Sulla TV apri il file ricevuto e conferma **Installa**.
4. GameDock compare tra le app della TV.

In alternativa, con un cavo/USB o via rete: `adb install GameDock.apk`.

## 3. Primo avvio

1. Sul PC GameDock Agent deve essere avviato.
2. Apri GameDock sulla TV: cerca il PC da solo. Se non lo trova, scrivi l'IP del PC (riga "Apri" nella finestra dell'Agent, senza `http://`).
3. Inserisci il codice di accesso dell'Agent (solo la prima volta).
4. Da quel momento l'app ricorda il PC. Quando il PC è online salva anche il suo indirizzo MAC: così, le volte successive, se il PC è spento puoi premere **Accendi PC**.

Per cambiare PC: GameDock › Impostazioni › PC › **Cambia PC (app TV)**, oppure "Cambia PC" nella schermata "PC spento".

## Aggiornare l'app

La maggior parte delle novità di GameDock (grafica, funzioni, libreria) arriva sulla TV da sola: l'app carica GameDock dal PC, quindi basta aggiornare la cartella `GameDockAgent`.

L'APK va rifatto solo se cambi la parte Android (icona, banner, schermate native, nuove funzioni della TV). In quel caso:

1. in `app/build.gradle` aumenta **`versionCode`** (es. da 2 a 3) e **`versionName`** (es. `'1.2'`);
2. **Build › Build APK(s)**;
3. copia `app-debug.apk` nella cartella **`GameDockAgent/apk/`** sul PC (il nome del file non conta).

Alla prossima apertura dell'app sulla TV compare **"È disponibile una nuova versione di GameDock TV"**: premi **AGGIORNA**. L'app scarica l'APK dal PC e apre l'installazione di Android; conferma con **Aggiorna**. Il PC salvato e le impostazioni restano.

- La prima volta Android chiede di **consentire a GameDock di installare app**: l'app apre la schermata giusta, attiva l'opzione, torna indietro e l'installazione parte da sola.
- La versione installata e quella disponibile sul PC sono anche in GameDock › Impostazioni › Controller e info.
- **Firma:** il progetto contiene una chiave fissa (`keystore/gamedock-debug.jks`), usata sia da Android Studio sia da GitHub: gli aggiornamenti funzionano sempre, da qualsiasi computer. Non cancellare quella cartella e tieni il repository GitHub **privato** (con la chiave chiunque potrebbe firmare un APK "GameDock").
- La versione 1.1 è la prima con l'aggiornamento automatico: se avevi installato una 1.0, questa volta installa la nuova a mano.

Chi apre GameDock dal browser della TV (senza app) trova in Impostazioni › Controller e info l'indirizzo per scaricare l'APK dal PC, da aprire con l'app **Downloader**.

## Telecomando e controller

- Telecomando: frecce, OK, Indietro.
- Controller Bluetooth: funziona come in GameDock (A seleziona, B indietro, X cerca, Y preferito, Start menu).

## Note

- L'APK è firmato con la chiave del progetto (`keystore/`): va benissimo per installarlo a mano. Per il Play Store servirebbe una chiave privata tua, da non condividere.
- Per vedere eventuali errori della pagina: con l'APK debug, collega la TV con adb e apri `chrome://inspect` in Chrome sul PC.
- Pacchetto: `com.lollomarta.gamedock`.
