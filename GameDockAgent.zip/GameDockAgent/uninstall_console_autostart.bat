@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (py -3 agent.py --remove-shortcuts autostart) else (python agent.py --remove-shortcuts autostart)
echo Avvio automatico di GameDock rimosso.
pause
