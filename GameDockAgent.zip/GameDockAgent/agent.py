"""
GameDock Agent - servizio locale per Windows.

Avvio:   python agent.py            (con finestra)
         pythonw agent.py           (in background, nessuna finestra)
Opzioni: --port 8765   --relay (solo Wake-on-LAN, ad es. su un Raspberry Pi)

Serve due cose sulla stessa porta:
  /api/...  -> API REST (azioni predefinite, protette da token)
  /...      -> la webapp GameDock compilata (cartella web/)
"""

import argparse
import base64
import hmac
import json
import logging
import mimetypes
import os
import string
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from urllib.parse import parse_qs, unquote, urlparse

import apkinfo
import console
import covers
import diagnostics
import launcher
import network
import profiles
import scanner
import shortcuts
import sysinfo
import sunshine
import storage

VERSION = "1.0.0"
MAX_BODY = 8 * 1024 * 1024          # 8 MB (copertine incluse)
MAX_COVER = 6 * 1024 * 1024
PLATFORMS = ("Steam", "EA", "Epic", "Ubisoft", "GOG", "Battle.net", "Xbox", "Rockstar", "Altro")

log = logging.getLogger("gamedock")
STATE = {"config": None, "relay": False}
_failed_auth = {}                    # ip -> [tentativi, primo_timestamp]
_failed_lock = threading.Lock()


# ------------------------------------------------------------ libreria ----

def _cover_url(game_id, lib, auto_cover):
    custom = lib["covers"].get(game_id)
    if custom and custom.startswith(("file:", covers.AUTO_PREFIX)):
        path = os.path.join(storage.COVERS_DIR, custom.split(":", 1)[1])
        if os.path.isfile(path):
            return f"/api/covers/{game_id}?v={int(os.path.getmtime(path))}"
    if custom and custom.startswith(("http://", "https://")):
        return custom
    if auto_cover and os.path.isfile(auto_cover):
        return f"/api/covers/{game_id}"
    return None


def all_games(force_scan=False, profile=None):
    """Unisce giochi rilevati e manuali, applicando preferiti, sessioni e copertine.
    Con un profilo: preferiti, "ultima volta" e tempo di gioco sono quelli del profilo."""
    cfg = STATE["config"]
    lib = storage.load_library()
    by_profile = profiles.per_game(lib.get("history", []), profile["id"]) if profile else None
    auto = [] if STATE["relay"] else scanner.scan_all(cfg["scan"], force=force_scan)
    manual = [dict(g, source="manual") for g in lib["manual"]]
    running = set(launcher.running_ids())
    favorites = set(profile.get("favorites", [])) if profile else set(lib["favorites"])
    hidden = set(lib.get("hidden", []))
    games = []
    for g in auto + manual:
        session = lib["sessions"].get(g["id"], {})
        if by_profile is not None:
            mine = by_profile.get(g["id"], {})
            last = mine.get("last") or None
            session = {"playtime": mine.get("seconds", 0)}
        else:
            last = max(filter(None, [g.get("lastPlayed"), session.get("lastPlayed")]), default=None)
        games.append({
            "id": g["id"],
            "name": g["name"],
            "platform": g.get("platform", "Altro"),
            "path": g.get("path"),
            "executable": g.get("executable") or (g.get("launch") or {}).get("path"),
            "args": (g.get("launch") or {}).get("args", ""),
            "cover": _cover_url(g["id"], lib, g.get("coverFile")),
            "favorite": g["id"] in favorites,
            "hidden": g["id"] in hidden,
            "tags": lib.get("tags", {}).get(g["id"], lib.get("autoTags", {}).get(g["id"], [])),
            "tagsManual": g["id"] in lib.get("tags", {}),
            "lastPlayed": last,
            "playtime": session.get("playtime", 0),
            "running": g["id"] in running,
            "source": g.get("source", "auto"),
            "launchType": (g.get("launch") or {}).get("type", "exe"),
            "_raw": g,
        })
    games.sort(key=lambda x: x["name"].lower())
    _record_first_seen(games, lib)
    return games


def _record_first_seen(games, lib):
    """Data in cui ogni gioco è comparso: serve per il badge "Nuovo".
    Al primo avvio tutti i giochi già presenti contano come vecchi."""
    seen = lib.get("firstSeen", {})
    missing = [g["id"] for g in games if g["id"] not in seen]
    if missing:
        now = int(time.time())
        first_run = not seen

        def mutate(lib):
            fs = lib.setdefault("firstSeen", {})
            for gid in missing:
                fs.setdefault(gid, 0 if first_run else now)
        storage.update_library(mutate)
        seen = {**seen, **{gid: (0 if first_run else now) for gid in missing}}
    for g in games:
        g["addedAt"] = seen.get(g["id"], 0)


def find_game(game_id, profile=None):
    return next((g for g in all_games(profile=profile) if g["id"] == game_id), None)


def public(game):
    return {k: v for k, v in game.items() if not k.startswith("_")}


def cover_jobs():
    return [(g["id"], g["name"], g["_raw"].get("appId"), g["cover"] is not None) for g in all_games()]


def start_cover_fetch(force=False):
    """Copertine e categorie automatiche da Steam, in background (se abilitate in config.json)."""
    if STATE["relay"] or not STATE["config"]["onlineCovers"].get("enabled"):
        return

    def job():
        covers.fetch_missing(cover_jobs(), force=force)
        tag_jobs = [(g["id"], g["name"], g["_raw"].get("appId"), bool(g["tags"])) for g in all_games()]
        covers.fetch_tags(tag_jobs, force=force)
    threading.Thread(target=job, daemon=True).start()


def sunshine_configured():
    sc = STATE["config"]["sunshine"]
    return bool(sc.get("username") and sc.get("password"))


def run_sunshine_sync():
    games = []
    for g in all_games():
        if g["hidden"]:
            continue
        raw = dict(g["_raw"])
        lib_cover = g["cover"] or ""
        if lib_cover.startswith("/api/covers/"):
            # copertina caricata/scaricata: Sunshine accetta solo PNG
            custom = storage.load_library()["covers"].get(g["id"], "")
            if ":" in custom:
                raw["coverFile"] = os.path.join(storage.COVERS_DIR, custom.split(":", 1)[1])
        games.append(raw)
    return sunshine.sync(STATE["config"]["sunshine"], games)


def start_sunshine_sync():
    """Sincronizzazione in background (se attiva e configurata)."""
    if STATE["relay"] or not sunshine_configured() or not STATE["config"]["sunshine"].get("autoSync", True):
        return

    def job():
        try:
            run_sunshine_sync()
        except sunshine.SunshineError as e:
            log.info("Sincronizzazione Sunshine non riuscita: %s", e)
    threading.Thread(target=job, daemon=True).start()


def record_launch(game_id, profile_id=None):
    def mutate(lib):
        s = lib["sessions"].setdefault(game_id, {})
        s["lastPlayed"] = int(time.time())
        s["count"] = s.get("count", 0) + 1
        profiles.history_start(lib, game_id, profile_id)
    storage.update_library(mutate)


def record_session_end(game_id, seconds):
    def mutate(lib):
        s = lib["sessions"].setdefault(game_id, {})
        s["playtime"] = s.get("playtime", 0) + max(0, seconds)
        profiles.history_end(lib, game_id, seconds)
    storage.update_library(mutate)
    # Modalità console: quando il gioco si chiude, GameDock torna in primo piano
    if STATE["config"]["console"].get("focusOnExit", True):
        console.focus_gamedock()


# ------------------------------------------------------------- handler ----

class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


class Handler(BaseHTTPRequestHandler):
    server_version = f"GameDockAgent/{VERSION}"

    # --- utilità -------------------------------------------------------
    def log_message(self, fmt, *args):
        log.debug("%s - %s", self.client_address[0], fmt % args)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-GameDock-Token, X-GameDock-Profile")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, cache="no-cache"):
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if path.endswith(".webmanifest") or path.endswith("manifest.json"):
            ctype = "application/manifest+json"
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ApiError(413, "Richiesta troppo grande.")
        if not length:
            return {}
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "JSON non valido.")
        if not isinstance(data, dict):
            raise ApiError(400, "Era atteso un oggetto JSON.")
        return data

    def _client_ip(self):
        return self.client_address[0]

    def _profile(self):
        """Profilo indicato dalla pagina (header X-GameDock-Profile), se esiste."""
        return profiles.get(self.headers.get("X-GameDock-Profile", "").strip())

    def _is_local_client(self, pc_ip):
        ip = self._client_ip()
        return network.is_loopback(ip) or ip == pc_ip

    def _require_lan(self):
        if STATE["config"]["lanOnly"] and not network.is_lan_address(self._client_ip()):
            raise ApiError(403, "Accesso consentito solo dalla rete di casa.")

    def _require_token(self):
        ip = self._client_ip()
        with _failed_lock:
            count, first = _failed_auth.get(ip, (0, 0))
            if count >= 10 and time.time() - first < 60:
                raise ApiError(429, "Troppi tentativi. Riprova tra un minuto.")
        token = self.headers.get("X-GameDock-Token", "")
        expected = STATE["config"]["token"]
        if token and hmac.compare_digest(token.strip().upper(), expected.upper()):
            with _failed_lock:
                _failed_auth.pop(ip, None)
            return
        with _failed_lock:
            count, first = _failed_auth.get(ip, (0, time.time()))
            if time.time() - first >= 60:
                count, first = 0, time.time()
            _failed_auth[ip] = (count + 1, first)
        raise ApiError(401, "Codice di accesso non valido.")

    # --- dispatch ------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def _dispatch(self, method):
        url = urlparse(self.path)
        path = unquote(url.path)
        try:
            self._require_lan()
            if path.startswith("/api/"):
                self._api(method, path, parse_qs(url.query))
            elif method == "GET":
                self._static(path)
            else:
                raise ApiError(405, "Metodo non consentito.")
        except ApiError as e:
            self._json(e.status, {"error": e.message})
        except launcher.LaunchError as e:
            self._json(400, {"error": str(e)})
        except Exception:
            log.exception("Errore interno su %s %s", method, path)
            self._json(500, {"error": "Errore interno dell'Agent. Controlla agent.log."})

    # --- webapp --------------------------------------------------------
    def _static(self, path):
        # Logo dello sponsor e altri file di branding: cartella branding/ accanto all'Agent
        if path.startswith("/branding/"):
            name = os.path.basename(path)
            if name.lower().endswith((".png", ".svg", ".webp", ".jpg", ".jpeg")):
                for folder in (storage.BRANDING_DIR, os.path.join(storage.WEB_DIR, "branding")):
                    candidate = os.path.join(folder, name)
                    if os.path.isfile(candidate):
                        return self._file(candidate, "no-cache")
            raise ApiError(404, "File non trovato.")
        web = os.path.realpath(storage.WEB_DIR)
        if not os.path.isdir(web):
            raise ApiError(404, "Webapp non trovata: manca la cartella web/.")
        target = os.path.realpath(os.path.join(web, path.lstrip("/")))
        if not target.startswith(web):
            raise ApiError(403, "Percorso non consentito.")
        if os.path.isfile(target):
            immutable = "/assets/" in path
            return self._file(target, "public, max-age=31536000, immutable" if immutable else "no-cache")
        if os.path.splitext(path)[1]:            # file con estensione inesistente
            raise ApiError(404, "File non trovato.")
        return self._file(os.path.join(web, "index.html"))   # fallback SPA

    # --- API -----------------------------------------------------------
    def _api(self, method, path, query):
        cfg = STATE["config"]
        parts = [p for p in path.split("/") if p][1:]     # senza "api"

        # Endpoint pubblici (nessun dato sensibile)
        if method == "GET" and parts == ["health"]:
            return self._json(200, {"status": "ok"})
        if method == "GET" and parts == ["status"]:
            adapter = network.adapter_info()
            return self._json(200, {
                "online": True, "pcName": cfg["pcName"], "platform": sys.platform,
                "ip": adapter["ip"], "mac": adapter["mac"], "connection": adapter["connection"],
                "port": cfg["port"], "version": VERSION, "relay": STATE["relay"],
                "runningGames": launcher.running_ids(),
                "clientIsLocal": self._is_local_client(adapter["ip"]),
                "coversBusy": covers.is_busy(),
            })
        if method == "GET" and parts == ["local", "token"]:
            # Solo per GameDock aperto sul PC stesso: chi è sul PC può comunque leggere config.json
            if not self._is_local_client(network.local_ip()):
                raise ApiError(403, "Disponibile solo sul PC.")
            return self._json(200, {"token": cfg["token"]})
        if method == "GET" and len(parts) == 2 and parts[0] == "covers":
            return self._cover(parts[1])
        # App GameDock TV: versione disponibile e download (pubblici: solo rete di casa)
        if method == "GET" and parts == ["app", "android"]:
            apk = apkinfo.latest()
            if not apk:
                return self._json(200, {"available": False})
            return self._json(200, {"available": True, "versionCode": apk["versionCode"],
                                    "versionName": apk["versionName"], "size": apk["size"]})
        if method == "GET" and parts == ["app", "android", "download"]:
            apk = apkinfo.latest()
            if not apk:
                raise ApiError(404, "Nessun APK nella cartella apk dell'Agent.")
            return self._apk(apk)

        self._require_token()

        if method == "POST" and parts == ["auth", "check"]:
            return self._json(200, {"ok": True, "pcName": cfg["pcName"]})

        if method == "POST" and parts == ["wake"]:
            body = self._body()
            mac = network.send_magic_packet(body.get("mac") or cfg["wake"]["mac"],
                                            body.get("broadcast") or cfg["wake"]["broadcast"],
                                            body.get("port") or cfg["wake"]["port"])
            log.info("Wake-on-LAN inviato a %s", mac)
            return self._json(200, {"ok": True, "mac": mac})

        if method == "GET" and parts == ["wake", "check"]:
            host = (query.get("host") or [""])[0]
            port = (query.get("port") or ["8765"])[0]
            if not host or not network.is_lan_address(host):
                raise ApiError(400, "Indirizzo non valido.")
            return self._json(200, {"reachable": network.tcp_reachable(host, port)})

        if STATE["relay"]:
            raise ApiError(404, "In modalità relay sono disponibili solo le funzioni di risveglio.")

        if parts[:1] == ["profiles"]:
            try:
                if method == "GET" and len(parts) == 1:
                    return self._json(200, {"profiles": profiles.list_profiles()})
                if method == "POST" and len(parts) == 1:
                    return self._json(201, {"profile": profiles.create(self._body())})
                if method == "PUT" and len(parts) == 2:
                    return self._json(200, {"profile": profiles.update(parts[1], self._body())})
                if method == "DELETE" and len(parts) == 2:
                    profiles.delete(parts[1])
                    return self._json(200, {"ok": True})
            except profiles.ProfileError as e:
                raise ApiError(400, str(e))
            raise ApiError(404, "Endpoint non trovato.")
        if parts[:1] == ["collections"]:
            return self._collections(method, parts[1:])

        if method == "POST" and parts == ["pc", "volume"]:
            action = self._body().get("action")
            if action not in ("up", "down", "mute"):
                raise ApiError(400, "Azione non valida.")
            if not console.volume(action):
                raise ApiError(400, "Volume disponibile solo su Windows.")
            return self._json(200, {"ok": True})
        if method == "GET" and parts == ["pc", "stats"]:
            return self._json(200, sysinfo.snapshot())
        if method == "GET" and parts == ["pc", "display"]:
            return self._json(200, {"current": console.current_resolution()})

        if method == "GET" and parts == ["stats"]:
            prof = self._profile()
            games = [public(g) for g in all_games(profile=prof)]
            return self._json(200, profiles.stats(prof["id"] if prof else None, games))

        if method == "GET" and parts == ["games"]:
            return self._json(200, {"games": [public(g) for g in all_games(profile=self._profile())]})
        if method == "POST" and parts == ["games", "rescan"]:
            return self._json(200, {"games": [public(g) for g in all_games(force_scan=True, profile=self._profile())]})
        if method == "POST" and parts == ["games"]:
            return self._add_game(self._body())
        if len(parts) >= 2 and parts[0] == "games":
            return self._game_action(method, parts[1], parts[2:])

        if method == "POST" and len(parts) == 2 and parts[0] == "pc" and parts[1] in ("shutdown", "restart", "cancel"):
            if not cfg.get("allowPower"):
                raise ApiError(403, "Spegnimento remoto disattivato in config.json.")
            launcher.power(parts[1])
            return self._json(200, {"ok": True, "action": parts[1]})

        if method == "POST" and parts == ["covers", "fetch"]:
            if not cfg["onlineCovers"].get("enabled"):
                raise ApiError(400, "Copertine automatiche disattivate.")
            result = covers.fetch_missing(cover_jobs(), force=bool(self._body().get("force")))
            return self._json(200, {**result, "games": [public(g) for g in all_games()]})
        if method == "POST" and parts == ["covers", "clear"]:
            removed = covers.clear_auto()
            return self._json(200, {"removed": removed, "games": [public(g) for g in all_games()]})

        if parts[:1] == ["sunshine"]:
            sc = cfg["sunshine"]
            try:
                if method == "GET" and parts == ["sunshine", "status"]:
                    if not sunshine_configured():
                        return self._json(200, {"configured": False, "ok": False})
                    return self._json(200, {"configured": True, **sunshine.test(sc),
                                            "managed": len(storage.load_library().get("sunshineApps", []))})
                if method == "POST" and parts == ["sunshine", "sync"]:
                    return self._json(200, run_sunshine_sync())
                if method == "POST" and parts == ["sunshine", "pin"]:
                    body = self._body()
                    return self._json(200, sunshine.pin(sc, body.get("pin"), body.get("name")))
            except sunshine.SunshineError as e:
                raise ApiError(400, str(e))
            raise ApiError(404, "Endpoint non trovato.")

        if method == "GET" and parts == ["pc", "shortcuts"]:
            return self._json(200, shortcuts.status())
        if method == "POST" and parts == ["pc", "shortcuts"]:
            try:
                return self._json(200, shortcuts.apply(self._body()))
            except shortcuts.ShortcutError as e:
                raise ApiError(400, str(e))

        if method == "GET" and parts == ["diagnostics"]:
            return self._json(200, diagnostics.run(cfg))
        if method == "GET" and parts == ["browse"]:
            return self._json(200, browse((query.get("path") or [""])[0]))
        if method == "GET" and parts == ["config"]:
            return self._json(200, safe_config())
        if method == "POST" and parts == ["config"]:
            return self._json(200, update_config(self._body()))

        raise ApiError(404, "Endpoint non trovato.")

    def _collections(self, method, rest):
        """Collezioni (cartelle di giochi create dall'utente), condivise tra i dispositivi."""
        body = self._body() if method in ("POST", "PUT") else {}

        def clean_name(value):
            name = " ".join(str(value or "").split())[:30]
            if not name:
                raise ApiError(400, "Dai un nome alla collezione.")
            return name

        if method == "GET" and not rest:
            return self._json(200, {"collections": storage.load_library().get("collections", [])})
        if method == "POST" and not rest:
            item = {"id": f"col-{int(time.time() * 1000) % 10**10}", "name": clean_name(body.get("name")),
                    "games": [g for g in body.get("games", []) if isinstance(g, str)][:500]}

            def add(lib):
                cols = lib.setdefault("collections", [])
                if len(cols) >= 30:
                    raise ApiError(400, "Puoi creare al massimo 30 collezioni.")
                cols.append(item)
            storage.update_library(add)
            return self._json(201, {"collection": item})
        if len(rest) >= 1:
            cid = rest[0]

            def change(lib):
                for c in lib.get("collections", []):
                    if c["id"] != cid:
                        continue
                    if method == "PUT" and len(rest) == 1:
                        if "name" in body:
                            c["name"] = clean_name(body["name"])
                        if isinstance(body.get("games"), list):
                            c["games"] = [g for g in body["games"] if isinstance(g, str)][:500]
                        return c
                    if method == "POST" and rest[1:] == ["games"]:
                        gid = str(body.get("gameId", ""))
                        c["games"] = [g for g in c["games"] if g != gid]
                        if body.get("add", True) and gid:
                            c["games"].append(gid)
                        return c
                    if method == "DELETE" and len(rest) == 1:
                        lib["collections"] = [x for x in lib["collections"] if x["id"] != cid]
                        return {"deleted": True}
                raise ApiError(404, "Collezione non trovata.")
            result = storage.update_library(change)
            return self._json(200, result if "deleted" in result else {"collection": result})
        raise ApiError(404, "Endpoint non trovato.")

    def _apk(self, apk):
        size = os.path.getsize(apk["path"])
        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", "application/vnd.android.package-archive")
        self.send_header("Content-Disposition", f'attachment; filename="GameDock-{apk["versionName"] or apk["versionCode"]}.apk"')
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with open(apk["path"], "rb") as f:
            while True:
                chunk = f.read(256 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
        log.info("APK %s scaricato da %s", apk["versionName"], self._client_ip())

    def _cover(self, game_id):
        lib = storage.load_library()
        custom = lib["covers"].get(game_id, "")
        path = None
        if custom.startswith(("file:", covers.AUTO_PREFIX)):
            path = os.path.join(storage.COVERS_DIR, os.path.basename(custom.split(":", 1)[1]))
        else:
            raw = next((g["_raw"] for g in all_games() if g["id"] == game_id), None)
            path = raw.get("coverFile") if raw else None
        if not path or not os.path.isfile(path):
            raise ApiError(404, "Copertina non trovata.")
        self._file(path, "public, max-age=86400")

    def _add_game(self, body):
        name = str(body.get("name", "")).strip()[:100]
        if not name:
            raise ApiError(400, "Inserisci il nome del gioco.")
        platform = body.get("platform") if body.get("platform") in PLATFORMS else "Altro"
        exe = launcher.validate_executable(body.get("executable"))
        args = str(body.get("args", ""))[:300]
        game_id = f"manual-{scanner.slugify(name)}-{int(time.time()) % 100000}"
        entry = {
            "id": game_id, "name": name, "platform": platform,
            "path": os.path.dirname(exe), "executable": exe,
            "launch": {"type": "exe", "path": exe, "args": args},
        }
        cover_url = str(body.get("coverUrl", "")).strip()

        def mutate(lib):
            lib["manual"].append(entry)
            if cover_url.startswith(("http://", "https://")):
                lib["covers"][game_id] = cover_url[:1000]
        storage.update_library(mutate)
        log.info("Gioco aggiunto a mano: %s", name)
        if not cover_url:
            start_cover_fetch()
        start_sunshine_sync()
        return self._json(201, {"game": public(find_game(game_id))})

    def _game_action(self, method, game_id, rest):
        prof = self._profile()
        game = find_game(game_id, prof)
        if not game:
            raise ApiError(404, "Gioco non trovato.")
        action = rest[0] if rest else ""

        if method == "POST" and action == "launch":
            guard = STATE["config"]["console"].get("hideLaunchers", True) and self._is_local_client(network.local_ip())
            result = launcher.launch(game["_raw"], record_session_end, guard=guard)
            if result.get("alreadyRunning"):
                # già aperto: invece di riavviarlo, lo riporta in primo piano
                try:
                    launcher.focus(game["_raw"])
                except launcher.LaunchError:
                    pass
            else:
                record_launch(game_id, prof["id"] if prof else None)
            return self._json(200, {"ok": True, **result, "game": public(find_game(game_id, prof))})

        if method == "POST" and action == "focus":
            launcher.focus(game["_raw"])
            return self._json(200, {"ok": True})

        if method == "POST" and action == "close":
            launcher.close(game_id)
            return self._json(200, {"ok": True})

        if method == "POST" and action == "favorite":
            fav = bool(self._body().get("favorite"))
            if prof:
                profiles.set_favorite(prof["id"], game_id, fav)
                return self._json(200, {"ok": True, "favorite": fav})

            def mutate(lib):
                favs = [f for f in lib["favorites"] if f != game_id]
                if fav:
                    favs.append(game_id)
                lib["favorites"] = favs
            storage.update_library(mutate)
            return self._json(200, {"ok": True, "favorite": fav})

        if method == "POST" and action == "hidden":
            hide = bool(self._body().get("hidden"))

            def mutate(lib):
                ids = [h for h in lib.get("hidden", []) if h != game_id]
                if hide:
                    ids.append(game_id)
                lib["hidden"] = ids
            storage.update_library(mutate)
            log.info("Gioco %s: %s", "nascosto" if hide else "di nuovo visibile", game["name"])
            start_sunshine_sync()
            return self._json(200, {"ok": True, "hidden": hide})

        if method == "POST" and action == "tags":
            body = self._body()

            def mutate(lib):
                if body.get("reset"):            # torna alle categorie automatiche
                    lib.setdefault("tags", {}).pop(game_id, None)
                else:
                    chosen = [t for t in body.get("tags", []) if t in covers.CATEGORIES]
                    lib.setdefault("tags", {})[game_id] = sorted(set(chosen))
            storage.update_library(mutate)
            return self._json(200, {"game": public(find_game(game_id, prof))})

        if method == "POST" and action == "cover":
            return self._set_cover(game_id, self._body())

        if method == "PUT" and not action:
            return self._edit_game(game, self._body())

        if method == "DELETE" and not action:
            if game["source"] != "manual":
                raise ApiError(400, "Solo i giochi aggiunti a mano possono essere rimossi.")

            def mutate(lib):
                lib["manual"] = [g for g in lib["manual"] if g["id"] != game_id]
                lib["favorites"] = [f for f in lib["favorites"] if f != game_id]
                lib["hidden"] = [h for h in lib.get("hidden", []) if h != game_id]
                lib["covers"].pop(game_id, None)
                lib["sessions"].pop(game_id, None)
            storage.update_library(mutate)
            start_sunshine_sync()
            return self._json(200, {"ok": True})

        raise ApiError(404, "Azione non trovata.")

    def _edit_game(self, game, body):
        if game["source"] != "manual":
            raise ApiError(400, "Solo i giochi aggiunti a mano possono essere modificati.")

        def mutate(lib):
            for g in lib["manual"]:
                if g["id"] != game["id"]:
                    continue
                if body.get("name"):
                    g["name"] = str(body["name"]).strip()[:100]
                if body.get("platform") in PLATFORMS:
                    g["platform"] = body["platform"]
                if "args" in body:
                    g["launch"]["args"] = str(body["args"])[:300]
                if body.get("executable"):
                    exe = launcher.validate_executable(body["executable"])
                    g["executable"] = g["launch"]["path"] = exe
                    g["path"] = os.path.dirname(exe)
        storage.update_library(mutate)
        return self._json(200, {"game": public(find_game(game["id"]))})

    def _set_cover(self, game_id, body):
        data_url = body.get("dataUrl")
        url = str(body.get("url", "")).strip()
        if data_url:
            try:
                header, encoded = data_url.split(",", 1)
                raw = base64.b64decode(encoded, validate=True)
            except (ValueError, base64.binascii.Error):
                raise ApiError(400, "Immagine non valida.")
            if len(raw) > MAX_COVER:
                raise ApiError(413, "Immagine troppo grande (massimo 6 MB).")
            if raw[:3] == b"\xff\xd8\xff":
                ext = "jpg"
            elif raw[:8] == b"\x89PNG\r\n\x1a\n":
                ext = "png"
            elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
                ext = "webp"
            else:
                raise ApiError(400, "Formato supportato: JPG, PNG o WebP.")
            os.makedirs(storage.COVERS_DIR, exist_ok=True)
            safe = scanner.slugify(game_id)
            for old in ("jpg", "png", "webp"):
                try:
                    os.remove(os.path.join(storage.COVERS_DIR, f"{safe}.{old}"))
                except OSError:
                    pass
            with open(os.path.join(storage.COVERS_DIR, f"{safe}.{ext}"), "wb") as f:
                f.write(raw)
            value = f"file:{safe}.{ext}"
        elif url.startswith(("http://", "https://")):
            value = url[:1000]
        elif body.get("reset"):
            value = None
        else:
            raise ApiError(400, "Invia un'immagine o un URL.")

        def mutate(lib):
            if value:
                lib["covers"][game_id] = value
            else:
                lib["covers"].pop(game_id, None)
        storage.update_library(mutate)
        return self._json(200, {"game": public(find_game(game_id))})


# --------------------------------------------------------- utilità API ----

def browse(path):
    """Elenca cartelle ed eseguibili, per scegliere un gioco dall'iPad/TV. Sola lettura."""
    if not path:
        if sys.platform.startswith("win"):
            drives = [f"{d}:\\" for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]
        else:
            drives = ["/"]
        return {"path": "", "parent": None,
                "entries": [{"name": d, "path": d, "type": "dir"} for d in drives]}
    path = os.path.normpath(path)
    if not os.path.isdir(path):
        raise ApiError(404, "Cartella non trovata.")
    entries = []
    try:
        for entry in sorted(os.scandir(path), key=lambda e: (not e.is_dir(), e.name.lower())):
            if entry.name.startswith(("$", ".")):
                continue
            try:
                if entry.is_dir():
                    entries.append({"name": entry.name, "path": entry.path, "type": "dir"})
                elif entry.name.lower().endswith(launcher.ALLOWED_EXTENSIONS):
                    entries.append({"name": entry.name, "path": entry.path, "type": "file"})
            except OSError:
                continue
            if len(entries) >= 500:
                break
    except PermissionError:
        raise ApiError(403, "Cartella non accessibile.")
    parent = os.path.dirname(path)
    return {"path": path, "parent": parent if parent != path else "", "entries": entries}


def safe_config():
    cfg = STATE["config"]
    return {"pcName": cfg["pcName"], "port": cfg["port"], "wake": cfg["wake"],
            "scan": cfg["scan"], "allowPower": cfg["allowPower"],
            "onlineCovers": cfg["onlineCovers"],
            "sunshine": {"url": cfg["sunshine"]["url"], "username": cfg["sunshine"]["username"],
                         "hasPassword": bool(cfg["sunshine"]["password"]),
                         "autoSync": cfg["sunshine"].get("autoSync", True),
                         "autoResolution": cfg["sunshine"].get("autoResolution", True)}}


def update_config(body):
    cfg = STATE["config"]
    if body.get("pcName"):
        cfg["pcName"] = str(body["pcName"]).strip()[:40]
    wake = body.get("wake") or {}
    if wake.get("mac"):
        try:
            cfg["wake"]["mac"] = network.normalize_mac(wake["mac"])
        except ValueError as e:
            raise ApiError(400, str(e))
    if wake.get("broadcast"):
        cfg["wake"]["broadcast"] = str(wake["broadcast"]).strip()[:45]
    scan = body.get("scan") or {}
    for key in ("steam", "ea", "epic", "ubisoft", "gog", "battlenet", "xbox", "rockstar"):
        if key in scan:
            cfg["scan"][key] = bool(scan[key])
    sun = body.get("sunshine") or {}
    if "url" in sun:
        url = str(sun["url"]).strip()[:200] or "https://localhost:47990"
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        cfg["sunshine"]["url"] = url
    if "username" in sun:
        cfg["sunshine"]["username"] = str(sun["username"]).strip()[:100]
    if sun.get("password"):                      # vuota = lascia quella salvata
        cfg["sunshine"]["password"] = str(sun["password"])[:200]
    if "autoSync" in sun:
        cfg["sunshine"]["autoSync"] = bool(sun["autoSync"])
    if "autoResolution" in sun:
        cfg["sunshine"]["autoResolution"] = bool(sun["autoResolution"])
        start_sunshine_sync()
    if "onlineCovers" in body:
        cfg["onlineCovers"]["enabled"] = bool((body.get("onlineCovers") or {}).get("enabled"))
    storage.save_config(cfg)
    return safe_config()


# ------------------------------------------------------- apertura launcher --

def open_launcher(port):
    """Apre GameDock in modalità console (Chrome o Edge a schermo intero, profilo dedicato)."""
    url = f"http://localhost:{port}/?console=1"
    kiosk = STATE["config"]["console"].get("kiosk", True)
    profile = os.path.join(os.environ.get("LOCALAPPDATA", storage.BASE_DIR), "GameDock", "browser")
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local = os.environ.get("LOCALAPPDATA", "")
    chrome = next((p for p in (
        os.path.join(pf, "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
    ) if os.path.isfile(p)), None)
    edge = next((p for p in (
        os.path.join(pf86, "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(pf, "Microsoft", "Edge", "Application", "msedge.exe"),
    ) if os.path.isfile(p)), None)
    common = ["--no-first-run", "--no-default-browser-check", "--disable-features=Translate"]
    if chrome:
        cmd = [chrome, f"--app={url}", f"--user-data-dir={os.path.join(profile, 'chrome')}", *common]
        if kiosk:
            cmd.insert(1, "--kiosk")
    elif edge:
        cmd = [edge, f"--user-data-dir={os.path.join(profile, 'edge')}", *common]
        cmd += ["--kiosk", url, "--edge-kiosk-type=fullscreen"] if kiosk else [f"--app={url}"]
    else:
        webbrowser.open(url)
        return
    subprocess.Popen(cmd, close_fds=True)
    log.info("Launcher aperto")


# ---------------------------------------------------------------- main ----

def setup_logging():
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    file_handler = RotatingFileHandler(storage.LOG_PATH, maxBytes=1_000_000, backupCount=2,
                                       encoding="utf-8")
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)
    if sys.stdout is not None:                       # pythonw non ha una console
        console = logging.StreamHandler(sys.stdout)
        console.setFormatter(logging.Formatter("%(message)s"))
        root.addHandler(console)


def main():
    parser = argparse.ArgumentParser(description="GameDock Agent")
    parser.add_argument("--port", type=int, help="porta HTTP (default da config.json)")
    parser.add_argument("--relay", action="store_true",
                        help="modalità relay: solo Wake-on-LAN, nessuna libreria")
    parser.add_argument("--open-console", action="store_true",
                        help="avvia l'Agent se serve e apre il launcher a schermo intero (icona GameDock)")
    parser.add_argument("--set-resolution", metavar="LxA@HZ",
                        help="cambia la risoluzione dello schermo ed esce (usato da Sunshine)")
    parser.add_argument("--restore-resolution", action="store_true",
                        help="ripristina la risoluzione normale ed esce (usato da Sunshine)")
    parser.add_argument("--shortcuts", metavar="TIPI",
                        help="crea i collegamenti ed esce: desktop,startMenu,autostart")
    parser.add_argument("--remove-shortcuts", metavar="TIPI",
                        help="rimuove i collegamenti ed esce: desktop,startMenu,autostart")
    args = parser.parse_args()

    setup_logging()
    if args.set_resolution or args.restore_resolution:
        if args.restore_resolution:
            console.restore_resolution()
        else:
            import re as _re
            m = _re.match(r"^(\d+)x(\d+)(?:@(\d+))?$", args.set_resolution.strip())
            if m:
                console.set_resolution(int(m.group(1)), int(m.group(2)), int(m.group(3)) if m.group(3) else None)
            else:
                log.error("Formato risoluzione non valido: %s (atteso 1920x1080@60)", args.set_resolution)
        return
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    mimetypes.add_type("image/svg+xml", ".svg")
    mimetypes.add_type("image/webp", ".webp")

    cfg = storage.load_config()
    if args.port:
        cfg["port"] = args.port
    STATE["config"] = cfg
    STATE["relay"] = args.relay

    if args.shortcuts or args.remove_shortcuts:
        changes = {k.strip(): True for k in (args.shortcuts or "").split(",") if k.strip()}
        changes.update({k.strip(): False for k in (args.remove_shortcuts or "").split(",") if k.strip()})
        try:
            result = shortcuts.apply(changes)
            log.info("Collegamenti: %s", result)
        except shortcuts.ShortcutError as e:
            log.error("Collegamenti non creati: %s", e)
        return

    if args.open_console and network.tcp_reachable("127.0.0.1", cfg["port"], timeout=1):
        # L'Agent è già in esecuzione: apriamo solo il launcher
        open_launcher(cfg["port"])
        return

    if not args.relay:
        sysinfo.start()

        def startup_scan():
            scanner.scan_all(cfg["scan"], force=True)
            start_cover_fetch()
            start_sunshine_sync()
        threading.Thread(target=startup_scan, daemon=True).start()

    if not args.relay and cfg["console"].get("homeButton", True) and console.IS_WINDOWS:
        # Tasto Xbox (o View + Menu) durante il gioco: torna a GameDock
        console.HomeButtonWatcher(lambda: console.focus_gamedock(delay=0)).start()

    server = ThreadingHTTPServer((cfg["host"], cfg["port"]), Handler)
    ip = network.local_ip()
    log.info("")
    log.info("  GameDock Agent %s%s", VERSION, " (relay)" if args.relay else "")
    log.info("  PC:      %s", cfg["pcName"])
    log.info("  Apri:    http://%s:%s", ip, cfg["port"])
    log.info("  Codice:  %s", cfg["token"])
    log.info("  Log:     %s", storage.LOG_PATH)
    log.info("")
    if args.open_console:
        threading.Timer(1.0, open_launcher, args=(cfg["port"],)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("Agent arrestato.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
