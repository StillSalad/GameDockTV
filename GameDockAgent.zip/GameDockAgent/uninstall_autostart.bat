@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\GameDock Agent.lnk" 2>nul
echo Avvio automatico rimosso. Per fermare l'Agent ora: Gestione attivita' ^> pythonw.exe ^> Termina attivita'.
pause
